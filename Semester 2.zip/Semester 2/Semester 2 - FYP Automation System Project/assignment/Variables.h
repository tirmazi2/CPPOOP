#pragma once
#include "ADMIN.h"
#include "EVALUATOR.h"
#include "PROJECT.h"
#include "STUDENT.h"
#include "SUPERVISOR.h"
#include <conio.h> //provides _getch() and _putch()
/////////////////////////////////////////////////////////////////////

//Fstream objects
ofstream writeTo;
ifstream readFrom;

//Dynamic Size
int StudentSize = 2; //static size for testing
int SupervisorSize = 2;
int EvaluatorSize = 2;
int ProjectSize = 2;

/*1- */Student *StudentObject = new Student[StudentSize];
/*2- */Admin *AdminObject;
/*3- */SupRecord *SupervisorObject = new SupRecord[SupervisorSize];
/*4- */Evaluator *EvaluatorObject = new Evaluator[EvaluatorSize];
/*5- */Project *ProjectObject = new Project[ProjectSize];
//delete statement for all has to be added at the end
/////////////////////////////////////////////////////////////////////

struct MyException : public exception {
	const char * what() const throw () {
		return "An exception is being thrown!";
	}
};
//Authentication
bool Login()
{
	string username, password;
	cout << setfill(' ') << setw(55) << "Username:\t\t\t"; cin >> username;
	cout << setfill(' ') << setw(55) << "Password:\t\t\t";
	
	//shows **** instead of real password
	char ch;
	ch = _getch();
	while (ch != 13) //character 13 is enter key
	{
		password.push_back(ch); //function is used to push elements from the back
		cout << '*';
		ch = _getch();
	}

	if (username == "123" && password == "123")
	{
		//////////////////////////////////////////////////////////////////////
		system("color 2"); // changes text color to green
		cout << endl << setfill(' ') << setw(65) << "Access Granted!" << endl;
		Sleep(300); //delays for 300 ms
		system("cls");
		/////////////////////////////////////////////////////////////////////
		return true;
	}
	else
	{
		return false;
	}
}
