#include "EVALUATOR.h"
#include "STUDENT.h"


//Class Evaluator Related
char Evaluator::getGrade(Project *p)
{
	if (Evaluator::marks == 0)
	{
		cout << "No projects assigned yet!" << endl;
	}
	else
	{
			if (Evaluator::marks >= 50 && marks <= 59)
			{
				return 'D';
			}
			else if (Evaluator::marks >= 60 && marks <= 69)
			{
				return 'C';
			}
			else if (Evaluator::marks >= 70 && marks < 79)
			{
				return 'B';
			}
			else if (Evaluator::marks >= 80 && marks <= 100)
			{
				return 'A';
			}
			else if(Evaluator::marks >= 1 && marks <= 49)
			{
				return 'F';
			}
			else
			{
				return '\0';
			}
		}	
}
void Evaluator::GradeProject(Project *p)
{
	if (p->getProjectId() == 0)
	{
		cout << "No projects assigned yet!" << endl;
	}
	else
	{
		cout << "Please enter Marks: "; cin >> marks;
	}
	
}
void Evaluator::CreatProfile()
{
	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	cout << "Please enter your Area of Expertise: ";
	cin >> Area_Exp;
	cout << "Please enter your University Name: ";
	cin.ignore(); getline(cin, University);
}
void Evaluator::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "University: " << University << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
	cout << endl;
}

Evaluator::Evaluator(int mar, char gr, string a, string b, string c, string d, string dep)
{
	marks = mar;
	grade = gr;
	F_Name = a;
	L_Name = b;
	University = c;
	Area_Exp = d;
	Department = dep;
}

Evaluator::~Evaluator()
{
}
//Searches Evaluator
void Evaluator::EvaluatorSearch(Evaluator EvaluatorTemp[], int& EvaluatorSize)
{
	string TempFirstName, TempLastName;
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;

	for (int i = 0; i < EvaluatorSize; ++i)
	{
		if (TempFirstName == EvaluatorTemp[i].F_Name && TempLastName == EvaluatorTemp[i].L_Name)
		{
			EvaluatorTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
	system("pause");
}
//Deletes a project record
void Evaluator::EvaluatorDelete(Evaluator *EvaluatorTemp, int& EvaluatorSize)
{
	int count = 0;
	string TempFirstName, TempLastName;

	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;

	for (int i = 0; i < EvaluatorSize; ++i)
	{
		//Finds element in the array
		if (TempFirstName == EvaluatorTemp[i].F_Name && TempLastName == EvaluatorTemp[i].L_Name)
		{
				if (i == EvaluatorSize - 1)
				{
					EvaluatorSize--;
				}
				else
				{
					//Lessens loop size from last position and then shifts to the right
					for (int j = i; j < EvaluatorSize - 1; ++j)
					{
						//Main condition to Swap ("Delete") each location
						EvaluatorTemp[j] = EvaluatorTemp[EvaluatorSize - 1];

						// updates the size for all student for loops
						EvaluatorSize--;
					}
				}
				//Counter to execute if statement
				++count;
			}
	}
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] EvaluatorTemp;
}

//gets Name
string Evaluator :: getFName()
{
	return F_Name;
}
string Evaluator::getLName()
{
	return L_Name;
}

//Filing
//Writing to file
void Evaluator::writeToFile(Evaluator *EvaluatorObject)
{
	/*ofstream WObjectCounter;
	WObjectCounter.open("TempObjectCounter.txt");

	if (!WObjectCounter.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{

		WObjectCounter.close();

		remove("ObjectCounter.txt");
		rename("TempObjectCounter.txt", "ObjectCounter.txt");
	}*/

	ofstream writeFile;
	writeFile.open("TempEvaluautorDetail.txt", ios::out);

	if (!writeFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			writeFile.write((char *)(&EvaluatorObject[index]), sizeof(EvaluatorObject[index]));
		}
		writeFile.close();

		remove("EvaluautorDetail.txt");
		rename("TempEvaluautorDetail.txt", "EvaluautorDetail.txt");
	}
}

//Reading from file
void Evaluator::readFromFile(Evaluator *EvaluatorObject)
{
	ifstream bookCounter;
	bookCounter.open("ObjectCounter.txt");

	if (!bookCounter.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{
		bookCounter.close();
	}

	ifstream readFile;
	readFile.open("EvaluautorDetail.txt", ios::in);

	if (!readFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			readFile.read((char *)(&EvaluatorObject[index]), sizeof(EvaluatorObject[index]));
		}
		readFile.close();
	}
}