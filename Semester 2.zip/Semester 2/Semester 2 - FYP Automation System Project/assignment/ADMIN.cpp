#include "ADMIN.h"



//Class Admin Related
Admin::Admin(string n, int exp)
{
	name = n;
	FieldExp = exp;
}

Admin::~Admin()
{
}

void Admin::viewProfile()
{
	cout << "Name: " << name << endl;
	cout << "Field Experience: " << FieldExp << endl;
}
void Admin::UpdateProfile()
{
	char AdminInput;
	cout << "1- Name \n2- Field Experience \nPlease make a choice: "; cin >> AdminInput;

	if (AdminInput == '1')
	{
		cout << "Please enter Name: "; cin.ignore();  getline(cin, name);
	}
	else if (AdminInput == '2')
	{
		cout << "Please enter Field Experience (Years in integer): "; cin >> FieldExp;
	}
	else
	{
		cout << "Invalid Choice!" << endl;
	}
}