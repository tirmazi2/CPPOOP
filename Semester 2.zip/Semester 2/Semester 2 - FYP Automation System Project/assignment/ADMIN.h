#pragma once //cause the current source file to be included only once in a single compilation
#include <iostream> //Standard Library
#include <string> //String Library
#include <fstream> //For file handling Library
#include <windows.h> //provides system functions like sleep function etc
#include <iomanip> //provides setw(),setf() etc
//#include "PROJECT.h" causing redefinition error
using namespace std;


class Admin
{
public:
	//Default Parameterized Constructor
	Admin(string n = "SYED ALI HAMZA", int exp = 5);
	~Admin();
	void viewProfile();
	void UpdateProfile();
	virtual void CreatProfile() = 0; //Creates New Project
	virtual void ShowProfile() = 0; //Shows Project
	
private:
	string name;
	int FieldExp;
};