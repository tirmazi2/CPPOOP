#pragma once
#include "ADMIN.h"


class Project : public Admin
{
protected:
	int P_Id;
private:
	string P_Title;
	string P_Detail;
	string P_S_Date;
	string P_E_Date;
	//Student *s[2];
	//SupRecord *sup;

public:
	//Default Parameterized Constructor
	Project(int e = 0, string a = "Automated FYP System", string b = "Details will go here", string c = "20/01/2019", string d = "20/10/2019");
	~Project();
	void CreatProfile(); //Creates New Project
	void ShowProfile(); //Shows Project
	void ProjectSearch(Project ProjectTemp[], int& ProjectSize); //Searches a record
	void ProjectDelete(Project *ProjectTemp, int& ProjectSize);
	int getProjectId();
	void readSequential(Project *ProjectObject);
	void writeToFile(Project *ProjectObject); //writes to a file
	void readFromFile(Project *ProjectObject); //reads from a file
};
