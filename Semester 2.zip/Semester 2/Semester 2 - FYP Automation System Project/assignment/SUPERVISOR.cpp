#include "SUPERVISOR.h"

ofstream SupervisorFile; //Object for filing

//Class Supervisor Record Related
SupRecord::SupRecord(string a, string b, string c, string d, string FT, string ST, string task, string taskdate)
{
	F_Name = a;
	L_Name = b;
	Department = c;
	Area_Exp = d;
	FirstTopic = FT;
	SecondTopic = ST;
	Task = task;
	TaskDate = taskdate;
}

SupRecord::~SupRecord()
{
}
void SupRecord::ProposedTopic(SupRecord *SupervisorObject)
{
	SupervisorFile.open("SupervisorTopics.txt");
	
		cout << "Please enter topics you want to propose" << endl;
		SupervisorFile << "Please enter topics you want to propose" << endl;
		cout << "First Topic: ";
		cin.ignore(); //Prevent getline from skipping input
		getline(cin, SupervisorObject->FirstTopic);
		SupervisorFile << "First Topic: " << SupervisorObject->FirstTopic << endl;
		cout << "Second Topic: ";
		cin.ignore(); //Prevent getline from skipping input
		getline(cin, SupervisorObject->SecondTopic);
		SupervisorFile << "Second Topic: " << SupervisorObject->SecondTopic << endl;

		SupervisorFile.close();
}

void SupRecord::CreatProfile()
{
	char temp;
	
	SupervisorFile.open("Supervisors.txt");

	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	SupervisorFile << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	SupervisorFile << "Department: " << Department << endl;
	cout << "Please enter your Area of Expertise: ";
	cin >> Area_Exp;
	SupervisorFile << "Area of Expertise: " << Area_Exp << endl;
	
	SupervisorFile << "\t\t\t\t\t\t\t---------Supervisor Details---------" << endl;
	SupervisorFile  << "\t\t\t\t\tFull Name" << "\t\t\tDepartment" << "\t\tArea of Expertise" << endl;
	SupervisorFile << "\t\t\t\t\t" << F_Name << " " << L_Name << "\t\t\t  " << Department << "\t\t\t  " << Area_Exp << endl << endl;

	//For Filing 
	ofstream writeTo;
	writeTo.open("ProjectDeatails.txt", ios::app | ios::binary);
	writeTo << setfill('-') << setw(120) << "-" << endl;
	writeTo << setfill(' ') << setw(70) << "Supervisor Details" << endl;
	//writeTo << setfill('*') << setw(120) << "*" << endl;

	writeTo << setfill(' ') << setw(45) << "Full Name: \t\t\t\t\t\t" << F_Name << " " << L_Name << endl;
	writeTo << setfill(' ') << setw(45) << "Department:\t\t\t\t\t\t" << Department << endl;
	writeTo << setfill(' ') << setw(51) << "Area of Expertise:\t\t\t\t\t" << Area_Exp << endl;

	writeTo.close();
	SupervisorFile.close();
}

void SupRecord::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
	cout << "Proposed Topics" << endl;
	cout << "1- " << FirstTopic << endl;
	cout << "2- " << SecondTopic << endl;
}
void SupRecord::SupervisorSearch(SupRecord SupervisorTemp[], int& SupervisorSize)
{
	string TempFirstName, TempLastName;
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;
	for (int i = 0; i < SupervisorSize; ++i)
	{
		if (TempFirstName == SupervisorTemp[i].F_Name && TempLastName == SupervisorTemp[i].L_Name)
		{
			SupervisorTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
}

//Deletes a project record
void SupRecord::SupervisorDelete(SupRecord *SupervisorTemp, int& SupervisorSize)
{
	int count = 0;
	string TempFirstName, TempLastName;
	
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;
	
	for (int i = 0; i < SupervisorSize; ++i)
	{
		//Finds element in the array
		if (TempFirstName == SupervisorTemp[i].F_Name && TempLastName == SupervisorTemp[i].L_Name)
		{
	
			if (i == SupervisorSize - 1)
			{
				SupervisorSize--;
			}
			else
			{
				//Lessens loop size from last position and then shifts to the right
				for (int j = i; j < SupervisorSize - 1; ++j)
				{
					//Forgot why did i added that statement :)
					if (SupervisorSize == SupervisorSize - 1)
					{
						break;
					}
					//Main condition to Swap ("Delete") each location
					SupervisorTemp[j] = SupervisorTemp[SupervisorSize - 1];

					// updates the size for all student for loops
					SupervisorSize--;
				}
			}
			//Counter to execute if statement
			++count;
		}
	}
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] SupervisorTemp;
}

void SupRecord::AssignTask(Project *p, Student *s)
{
	if (p[0].getProjectId() == 0 && p[1].getProjectId() == 0)
	{
		cout << "No Projects assigned yet!" << endl;
	}
	else
	{
		string temp;
		cout << "Please enter student Enrollment Number: "; cin >> temp;
		if (temp == s[0].getStudentEID())
		{
			cout << "Project ID: " << p[0].getProjectId() << endl;
			cout << "Please enter a Task: "; cin.ignore(); getline(cin, Task);
			cout << "Please enter Deadline: "; cin >> TaskDate;
		}
		else if (temp == s[1].getStudentEID())
		{
			cout << "Project ID: " << p[1].getProjectId() << endl;
			cout << "Please enter a Task: "; cin.ignore(); getline(cin, Task);
			cout << "Please enter Deadline: "; cin >> TaskDate;
		}
	}
}

string SupRecord::getAssignTask()
{
	return Task;
}

string SupRecord::getAssignedTaskDate()
{
	return TaskDate;
}

string SupRecord::getSupervisorFirstName()
{
	return F_Name;
}
string SupRecord::getSupervisorLastName()
{
	return L_Name;
}
//Writing to File
void SupRecord::writeToFile(SupRecord *SupervisorObject)
{
	/*ofstream WObjectCounter;
	WObjectCounter.open("TempObjectCounter.txt");

	if (!WObjectCounter.is_open())
	{
	cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{

	WObjectCounter.close();

	remove("ObjectCounter.txt");
	rename("TempObjectCounter.txt", "ObjectCounter.txt");
	}*/

	ofstream writeFile;
	writeFile.open("TempSupervisorDetail.txt", ios::out);

	if (!writeFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			writeFile.write((char *)(&SupervisorObject[index]), sizeof(SupervisorObject[index]));
		}
		writeFile.close();

		remove("SupervisorDetail.txt");
		rename("TempSupervisorDetail.txt", "SupervisorDetail.txt");
	}
}
//Reading
void SupRecord::readFromFile(SupRecord *SupervisorObject)
{
	/*ifstream bookCounter;
	bookCounter.open("ObjectCounter.txt");

	if (!bookCounter.is_open())
	{
	cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{
	bookCounter.close();
	}*/

	ifstream readFile;
	readFile.open("SupervisorDetail.txt", ios::in);

	if (!readFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			readFile.read((char *)(&SupervisorObject[index]), sizeof(SupervisorObject[index]));
		}
		readFile.close();
	}
}
