#pragma once
#include "Admin.h"
#include "PROJECT.h"
#include "STUDENT.h"
#include <iomanip>


class SupRecord : public Admin, public Project
{
	string F_Name;
	string L_Name;
	string Department;
	string Area_Exp;
	string FirstTopic;
	string SecondTopic;
	string Task;
	string TaskDate;

public:
	//Default Parameterized Constructor
	SupRecord(string a = "Empty", string b = "Empty", string c = "Empty", string d = "System Administrator", string FT = "Empty", string ST = "Empty", string task = "Login Screen", string taskdate = "26 / 12 / 2019");
	~SupRecord();
	
	void CreatProfile(); //Creates New Supervisor Profile
	void ShowProfile(); //Shows Supervisor Profile
	void ProposedTopic(SupRecord *SupervisorObject); // Shows Proposed topics by a perticular supervisor
	void SupervisorSearch(SupRecord SupervisorTemp[], int& SupervisorSize); //Search
	void SupervisorDelete(SupRecord *SupervisorTemp, int& SupervisorSize); //Delete
	void AssignTask(Project *p, Student *s);
	string getAssignTask();
	string getAssignedTaskDate();
	string getSupervisorFirstName();
	string getSupervisorLastName();
	void writeToFile(SupRecord *SupervisorObject); //writes to a file
	void readFromFile(SupRecord *SupervisorObject); //reads from a file
};