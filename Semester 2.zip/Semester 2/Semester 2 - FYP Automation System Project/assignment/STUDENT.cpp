#include "STUDENT.h"


// Class Student Related
Student::Student(string a, string b, string c, string d, string e, int f, string PStatus)
{
	F_Name = a;
	L_Name = b;
	Enrollment = c;
	Semester = d;
	Session = e;
	Year = f;
	ProjectStatus = PStatus;
}

Student::~Student()
{
}

void Student::CreatProfile()
{
	
	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	cout << "Please enter your Enrollment Number: ";
	cin >> Enrollment;
	cout << "Please enter your Semester: ";
	cin >> Semester;
	cout << "Please enter your Session: ";
	cin >> Session;
	cout << "Please enter Enrollment Year: ";
	cin >> Year;

	//For Filing 
	ofstream writeTo;
	writeTo.open("ProjectDeatails.txt", ios::app | ios::binary);
	writeTo << setfill('-') << setw(120) << "-" << endl;
	writeTo << setfill(' ') << setw(70) << "Student Details" << endl;
	//writeTo << setfill('*') << setw(120) << "*" << endl;
	
	writeTo << setfill(' ') << setw(45) << "Full Name: \t\t\t\t\t\t" << F_Name << " " << L_Name << endl;
	writeTo << setfill(' ') << setw(51) << "Enrollment Number:\t\t\t\t\t" << Enrollment << endl;
	writeTo << setfill(' ') << setw(43) << "Semester:\t\t\t\t\t\t" << Semester << endl;
	writeTo << setfill(' ') << setw(42) << "Session:\t\t\t\t\t\t" << Session << endl;
	writeTo << setfill(' ') << setw(49) << "Enrollment Year:\t\t\t\t\t" << Year << endl;
	writeTo.close();

}

string Student::ProStatus(Project *p)
{
	/*if (p[0].getProjectId() != 0 && p[1].getProjectId() != 0)
	{
	*/	//ProjectStatus = "Assigned";
		return ProjectStatus;
	//}
}

void Student::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Enrollment Number: " << Enrollment << endl;
	cout << "Semester: " << Semester << endl;
	cout << "Session: " << Session << endl;
	cout << "Enrollment Year: " << Year << endl;
}

void Student::UpdateProfile(Student *s)
{
	int UpdateInput;
	cout << endl << "1- Student Name \n2- Student Enrollment \n3- Student Semester \n4- Student Session \n5- Student Enrollment Year \n6- Project Status" << endl;
	cout << "What do you want to update?: "; cin >> UpdateInput;
	if (UpdateInput == 1)
	{
		cout << "Please enter your First Name: ";
		cin >> s->F_Name;
		cout << "Please enter your Last Name: ";
		cin >> s->L_Name;
	}
	else if (UpdateInput == 2)
	{
		cout << "Please enter your Enrollment Number: ";
		cin >> s->Enrollment;
	}
	else if (UpdateInput == 3)
	{
		cout << "Please enter your Semester: ";
		cin >> s->Semester;
	}
	else if (UpdateInput == 4)
	{
		cout << "Please enter your Session: ";
		cin >> s->Session;
	}
	else if (UpdateInput == 5)
	{
		cout << "Please enter Enrollment Year: ";
		cin >> s->Year;
	}
	else if (UpdateInput == 6)
	{
	again: //jump statement (old is gold)
		cout << "1- Assigned \n2- Under Implementation \nPlease make a choice: "; cin >> ProjectStatus;

		if (ProjectStatus == "1")
		{
			ProjectStatus = "Assigned";
		}
		else if(ProjectStatus == "2")
		{
			ProjectStatus = "Under Implementation";
		}
		else if (s->ProjectStatus != "1" && s->ProjectStatus != "2")
		{
			cout << "Choose between 'Assigned or Under Implementation only!'" << endl;
			system("pause");
			system("cls");
			goto again;
		}

	}
	else
	{
		
		cout << "No such information available!" << endl;
	}
	
}

void Student::StudentSearch(Student Studenttemp[], int& StudentSize)
{
	string temp;
	cout << "Please enter student enrollment number: "; cin >> temp;
	for (int i = 0; i < StudentSize; ++i)
	{
		if (temp == Studenttemp[i].Enrollment)
		{
			Studenttemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
			break;
		}
	}
}

//Deletes a student record
void Student::StudentDelete(Student *Studenttemp, int& StudentSize)
{
	string Del;
	int count = 0;
	cout << "Please enter id to delete: "; cin >> Del;
	for (int i = 0; i < StudentSize; ++i)
	{
		//Finds element in the array
		if (Del == Studenttemp[i].Enrollment)
		{	
					//Main condition to Swap ("Delete") each location
					Studenttemp[i] = Studenttemp[StudentSize - 1];
					// updates the size for all student for loops
					StudentSize--;
			//Counter to execute if statement
			++count;
			break;
		}//end of if main
	}//end of for loop
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}
	
	//delete[] Studenttemp;
}

void Student::setStudentSize(int& StudentSize)
{
	cout << "How many Students you wanna add?: "; cin >> StudentSize;
}

string Student::getStudentEID()
{
	return Enrollment;
}
//Writing to File
void Student::writeToFile(Student *StudentObject)
{
	/*ofstream WObjectCounter;
	WObjectCounter.open("TempObjectCounter.txt");

	if (!WObjectCounter.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{

		WObjectCounter.close();

		remove("ObjectCounter.txt");
		rename("TempObjectCounter.txt", "ObjectCounter.txt");
	}*/

	ofstream writeFile;
	writeFile.open("TempStudentDetail.txt", ios::out);

	if (!writeFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			writeFile.write((char *)(&StudentObject[index]), sizeof(StudentObject[index]));
		}
		writeFile.close();

		remove("StudentDetail.txt");
		rename("TempStudentDetail.txt", "StudentDetail.txt");
	}
}
//Reading
void Student::readFromFile(Student *StudentObject)
{
	/*ifstream bookCounter;
	bookCounter.open("ObjectCounter.txt");

	if (!bookCounter.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{
		bookCounter.close();
	}*/

	ifstream readFile;
	readFile.open("StudentDetail.txt", ios::in);

	if (!readFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			readFile.read((char *)(&StudentObject[index]), sizeof(StudentObject[index]));
		}
		readFile.close();
	}
}