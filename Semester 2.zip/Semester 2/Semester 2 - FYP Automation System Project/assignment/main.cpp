#include "ADMIN.h" //Admin class Definition and Declartion
#include "SUPERVISOR.h" //Supervisor class Definition and Declartion
#include "EVALUATOR.h" //Evaluator class Definition and Declartion
#include "STUDENT.h" //Student class Definition and Declartion
#include "PROJECT.h" //Project class Definition and Declartion
#include "Variables.h"

		/*AUTOMATED FINAL YEAR PROJECT
		Concepts used are:
		1- Encapuslation (All classes)
		2- Inheritance (Supervisor, Evaluator, Project, Student)
		3- Aggregation (Evaluator, Project, Student)
		4- Polymorphism (Supervisor, Evaluator, Project, Student)*/

		//////Update Required!
		/////1- Checks on all inputs


int main()
{
	/////////////////////////////////////////////////////
					/*Loading Screen*/
	/////////////////////////////////////////////////////
	cout << "\n\n\n\n\n\n\n\n\t\t\t\t\tLoading:  ";
	for (int i = 0; i < 20; ++i)
	{
		system("color 4");
		cout << "=";
		Sleep(150);
		//system("color 10");
		if (i == 19)
		{
			cout << ">>>";
		}
	}
	system("cls");
	system("color 9");
	/////////////////////////////////////////////////////

MainLoginScreen: //Retrun flag 

	char UserChoice;
	
	do {
		system("cls");
		cout << setfill('*') << setw(120) << "*" << endl;
		cout << setfill(' ') << setw(68) << "User Portal" << endl;
		cout << setfill('*') << setw(120) << "*" << endl;
		cout << "1- Admin \n2- Superviosr \n3- Student \n4- Evaluator \n0- Exit \nPlease make a choice: ";
		cin >> UserChoice;
		system("cls");

		switch (UserChoice)
		{
		case '1':
		{
			cout << setfill('*') << setw(120) << "*" << endl;
			cout << setfill(' ') << setw(70) << "Admin Login Portal" << endl;
			cout << setfill('*') << setw(120) << "*" << endl;


			if (Login() == true)
			{
				system("color 7"); // changes text color to white
				char AdminInput;

			AdminMainMenu: //Jumps here

				do {
					cout << "1- Update Admin Profile \n2- Project \n3- Superviosr \n4- Evaluator \n5- Student \nb- Back \nPlease make a choice: ";
					cin >> AdminInput;

					switch (AdminInput)
					{
					case '1':
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "Update Profile" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;
						
						if (AdminInput == '1')
						{
							try {
								throw MyException(); //an exception declared in Variables.h
							}
							catch (MyException& excep) {
								//what() is an overridden function for all child exception classes provided by exception class
								cout << excep.what() << endl;
							}
						}

						break;
					} // end of Admin Update
					case '2':
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "Project Allocation" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << "1- Add Project \n2- Search Project \n3- Show All Projects \n4- Delete Projects \n5- DataBases \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{

							for (int i = 0; i < ProjectSize; ++i)
							{
								system("cls");
								cout << setfill('*') << setw(120) << "*" << endl;
								cout << setfill(' ') << setw(70) << "Add Project" << endl;
								cout << setfill('*') << setw(120) << "*" << endl;

								cout << endl << "Project " << i + 1 << endl;
								cout << "Project Information: " << endl <<endl;
								ProjectObject[i].CreatProfile();

								//Prevents from allocating same Project ID
								if (ProjectObject[0].getProjectId() == ProjectObject[1].getProjectId())
								{
									Project tempObject;
									system("cls");
									cout << "ID MATCH ERROR:- Project ID " << ProjectObject[0].getProjectId()
										<< " already exists, please correct then try again!" << endl;
									Sleep(1000);
									ProjectObject[0] = ProjectObject[1] = tempObject;
									system("cls");

									break;
								}
								cout << endl << "Student Information: " << endl << endl;
								StudentObject[i].CreatProfile();

								//Prevents from allocating same Student ID
								if (StudentObject[0].getStudentEID() == StudentObject[1].getStudentEID())
								{
									Student tempObject;
									system("cls");
									cout << "ID MATCH ERROR:- Student ID " << StudentObject[0].getStudentEID()
										<< " already exists, please correct then try again!" << endl;
									Sleep(1000);

									//if gets error then set value to default values
									StudentObject[0] = StudentObject[1] = tempObject;
									system("cls");

									break;
								}

								cout << endl << "Supervisor Information: " << endl << endl;
								SupervisorObject[i].CreatProfile();
							}

							break;
						}
						case '2':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Project Search" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							if (ProjectSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								ProjectObject->ProjectSearch(ProjectObject, ProjectSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Show Current Project" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
	
							for (int i = 0; i < ProjectSize; ++i)
							{
								cout << endl << "Project " << i + 1 << endl;
								ProjectObject[i].ShowProfile(); cout << endl;
							}

							break;
						}
						case '4':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Delete Project" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							ProjectObject->ProjectDelete(ProjectObject, ProjectSize);

							break;
						}
						case '5':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "DataBase" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							//Object ProObject to store original Objects data
							//pro to call both functions
							Project ProObject[2], pro;

							cout << "Random Access Filing" << endl;

							for (int i = 0; i < 2; i++)
							{
								pro.writeToFile(ProjectObject);
								pro.readFromFile(ProObject);
								ProObject[i].ShowProfile();
							}

							pro.readSequential(ProjectObject);

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default: cout << "Invalid Choice!" << endl;
							break;
						} // end of Admin (Project)

						break;

					}// end of Project Menu

					case '3':
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "SUPERVISOR" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << "1- Add Supervisor \n2- Search Supervisor \n3- Show Current Supervisor \n4- Delete a Supervisor \n5- DataBase \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Add Supervisor" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							for (int i = 0; i < SupervisorSize; ++i)
							{
								cout << endl << "Supervisor " << i + 1 << endl;
								SupervisorObject[i].CreatProfile();
							}

							break;
						}
						case '2':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Supervisor Search" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							if (SupervisorSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								SupervisorObject->SupervisorSearch(SupervisorObject, SupervisorSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Show Current Supervisor" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							for (int i = 0; i < SupervisorSize; ++i)
							{
								cout << endl << "Supervisor " << i + 1 << endl;
								SupervisorObject[i].ShowProfile(); cout << endl;
							}

							break;
						}
						case '4':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Delete Supervisor" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							SupervisorObject->SupervisorDelete(SupervisorObject, SupervisorSize);

							break;
						}
						case '5':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "DataBase" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							//Object SupervisorObject to store original Objects data
							//sup to call both functions
							SupRecord SupObject[2], sup;

							for (int i = 0; i < 2; i++)
							{
								sup.writeToFile(SupervisorObject);
								sup.readFromFile(SupObject);
								SupObject[i].ShowProfile();
							}

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default:
							break;
						}// end of Admin (Supervisor)

						break;

					} // end of Supervisor Menu
					case '4':
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "EVALUATOR" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << "1- Add Evaluator \n2- Search Evaluator \n3- Show Current Evaluators \n4- Delete An Evaluator \n5- DataBase \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Add Evaluator" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							for (int i = 0; i < EvaluatorSize; ++i)
							{
								cout << endl << "Evaluator " << i + 1 << endl;
								EvaluatorObject[i].CreatProfile();
							}
							
							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case '2':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Search Evaluator" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							if (EvaluatorSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								EvaluatorObject->EvaluatorSearch(EvaluatorObject, EvaluatorSize);
							}

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case '3':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Show Current Evaluator" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							
							for (int i = 0; i < EvaluatorSize; i++)
							{
								cout << endl << "Evaluator " << i + 1 << endl;
								EvaluatorObject[i].ShowProfile(); cout << endl;
							}
							
							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case '4':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Delete Evaluator" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							EvaluatorObject->EvaluatorDelete(EvaluatorObject, EvaluatorSize);

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case '5':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "DataBase" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							//Object EvaObject to store original Objects data
							//eval to call both functions
							Evaluator EvaObject[2], eval;

							for (int i = 0; i < 2; i++)
							{
								eval.writeToFile(EvaluatorObject);
								eval.readFromFile(EvaObject);
								EvaObject[i].ShowProfile();
							}

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default: //Evaluator Default
						{
							cout << "invalid choice!" << endl;
							break;
						}
						break;
						} //end of Switch Evaluator
					}// end of Evaluator Menu
					case '5':
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "STUDENT" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << "1- Add Student \n2- Search Student \n3- Show All Students \n4- Delete Student \n5- DataBase \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;
							
						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Add Student" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							for (int i = 0; i < StudentSize; ++i)
							{
								int count = 0;
								int temp;
								cout << endl << "Student " << i + 1 << endl;
								StudentObject[i].CreatProfile();

								//Prevents from allocating same Student ID
								if (StudentObject[0].getStudentEID() == StudentObject[1].getStudentEID())
								{
									Student tempObject;
									system("cls");
									cout << "ID MATCH ERROR:- Student ID " << StudentObject[0].getStudentEID()
										<< " already exists, please correct then try again!" << endl;
									Sleep(1000);
									StudentObject[0] = StudentObject[1] = tempObject;
									system("cls");

									break;
								}
							}

							break;
						}
						case '2':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Search Student" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							if (StudentSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								StudentObject->StudentSearch(StudentObject, StudentSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Show All Student" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							for (int i = 0; i < StudentSize; ++i)
							{
								cout << endl << "Student " << i + 1 << endl;
								StudentObject[i].ShowProfile(); cout << endl;
							}
							cout << endl;
							system("pause");
							break;
						}
						case '4':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "Delete Student" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							StudentObject->StudentDelete(StudentObject, StudentSize);

							break;
						}
						case '5':
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "DataBase" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;
							//Object EvaObject to store original Objects data
							//eval to call both functions
							Student StuObject[2], stu;

							for (int i = 0; i < 2; i++)
							{
								stu.writeToFile(StudentObject);
								stu.readFromFile(StuObject);
								StuObject[i].ShowProfile();
							}

							system("pause");
							system("cls");
							goto AdminMainMenu;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default:
						{
							cout << "Invalid Choice!" << endl;
							break;
						}

						} //end of switch Student Menu
						break;
					} // end of case 5 "Student"
					case 'b':
					{
						system("cls");
						goto MainLoginScreen;
					}
					default:
					{	//cout << "Invalid Choice" << endl;
						break;
					}

					} //end of Sub Admin (for Admin sub menus)

					system("pause");
					system("cls");
				} while (AdminInput != '0'); //end of do while (Admin)

			} //end of password if statement
			else
			{
				cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
				cout << "Wrong password or username!" << endl;
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			}
			break;

		} //end of case 1 (login)

		case '2':
		{
			cout << setfill('*') << setw(120) << "*" << endl;
			cout << setfill(' ') << setw(70) << "Supervisor Login Portal" << endl;
			cout << setfill('*') << setw(120) << "*" << endl;

			if (Login() == true)
			{
				
			SupervisorFlag: //Jump statement

				system("color 7"); // changes text color to white
				//SupRecord SupervisorObject;
				string tempfname, templname;
				char SupervisorInput;
				do {
					system("cls");
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << setfill(' ') << setw(70) << "Supervisor Portal" << endl;
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << "1- Propose Topic(s) \n2- ID of Groups Assigned \n3- Assign Tasks with Deadline \n4- View Student Profile\ Project Status\ Task update \n5- Grade of Groups \nb- Back \nPlease make a choice: ";
					cin >> SupervisorInput;

					system("cls");

					if (SupervisorInput == '1')
					{

						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "PROPOSE TOPIC(S)" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						//finds related supervisor and assigns topics
						cout << "Please enter your First Name: "; cin >> tempfname;
						cout << "Please enter your Last Name: "; cin >> templname;
						if (tempfname == SupervisorObject[0].getSupervisorFirstName()
							&& templname == SupervisorObject[0].getSupervisorLastName())
						{
							SupervisorObject[0].ProposedTopic(&SupervisorObject[0]);
						}
						else if (tempfname == SupervisorObject[1].getSupervisorFirstName()
							&& templname == SupervisorObject[1].getSupervisorLastName())
						{
							SupervisorObject[1].ProposedTopic(&SupervisorObject[1]);
						}
					}
					else if (SupervisorInput == '2')
					{

						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "GROUP ID ASSINED" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						if (ProjectObject[0].getProjectId() == 0
							&& ProjectObject[1].getProjectId() == 0)
						{
							cout << "No Projects assigned yet!" << endl;

							system("pause");
							goto SupervisorFlag;
						}
						//finds assigned project id
						cout << "Please enter your First Name: "; cin >> tempfname;
						cout << "Please enter your Last Name: "; cin >> templname;
						if (tempfname == SupervisorObject[0].getSupervisorFirstName()
							&& templname == SupervisorObject[0].getSupervisorLastName())
						{
							cout << "Project ID: " << ProjectObject[0].getProjectId() << endl;
						}
						else if (tempfname == SupervisorObject[1].getSupervisorFirstName()
							&& templname == SupervisorObject[1].getSupervisorLastName())
						{
							cout << "Project ID: " << ProjectObject[1].getProjectId() << endl;
						}


						system("pause");
					}
					else if (SupervisorInput == '3')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "ASSIGN TASK WITH DEADLINE" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						SupervisorObject->AssignTask(ProjectObject, StudentObject);

						system("pause");
					}
					else if (SupervisorInput == '4')
					{
						system("cls");
						cout << "==========View\ STUDENT PROFILE\ PROJECT STATUS\ TASK UPDATE==========" << endl;
						cout << endl << "1- View Student Profile \n2- View Project Status \n3- Task Update \nPlease make a choice: ";
						cin >> SupervisorInput;
						if (SupervisorInput == '1')
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "VIEW STUDENT PROFILE" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							if (ProjectObject[0].getProjectId() == 0
								&& ProjectObject[1].getProjectId() == 0)
							{
								cout << "No students assigned yet!" << endl;

								system("pause");
								goto SupervisorFlag;
							}

							cout << "Please enter your First Name: "; cin >> tempfname;
							cout << "Please enter your Last Name: "; cin >> templname;
							if (tempfname == SupervisorObject[0].getSupervisorFirstName()
								&& templname == SupervisorObject[0].getSupervisorLastName()
								&& ProjectObject[0].getProjectId() != 0
								&& ProjectObject[1].getProjectId() != 0)
							{
								StudentObject[0].ShowProfile();
							}
							else if (tempfname == SupervisorObject[1].getSupervisorFirstName()
								&& templname == SupervisorObject[1].getSupervisorLastName()
								&& ProjectObject[0].getProjectId() != 0
								&& ProjectObject[1].getProjectId() != 0)
							{
								StudentObject[1].ShowProfile();

							}


						}
						else if (SupervisorInput == '2')
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "PROJECT STATUS" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							cout << "Project Stauts: " << StudentObject->ProStatus(ProjectObject) << endl;
						}
						else if (SupervisorInput == '3')
						{
							system("cls");
							cout << setfill('*') << setw(120) << "*" << endl;
							cout << setfill(' ') << setw(70) << "TASK UPDATE" << endl;
							cout << setfill('*') << setw(120) << "*" << endl;

							SupervisorObject->AssignTask(ProjectObject, StudentObject);
						}
						system("pause");
					}
					else if (SupervisorInput == '5')
					{
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "ASSIGNED GROUPS GRADES" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						if (ProjectObject[0].getProjectId() == 0
							&& ProjectObject[1].getProjectId() == 0)
						{
							cout << "No students or projects assigned yet!" << endl;
							break;
							system("pause");
							goto SupervisorFlag;
						}
						else
						{
							cout << "Please enter your First Name: "; cin >> tempfname;
							cout << "Please enter your Last Name: "; cin >> templname;
							if (tempfname == SupervisorObject[0].getSupervisorFirstName()
								&& tempfname == SupervisorObject[0].getSupervisorLastName())
							{
								cout << "Grade: " << EvaluatorObject[0].getGrade(&ProjectObject[0]) << endl;
							}
							else if (tempfname == SupervisorObject[1].getSupervisorFirstName()
								&& tempfname == SupervisorObject[1].getSupervisorLastName())
							{
								cout << "Grade: " << EvaluatorObject[1].getGrade(&ProjectObject[1]) << endl;
							}

						}

						system("pause");
					}
					else if (SupervisorInput == 'b')
					{
						system("cls");
						goto MainLoginScreen;
					}
					else
					{
						cout << "Wrong Input, Try again " << endl;

						system("pause");
						system("cls");
					}//end of supervisor if statement
				} while (SupervisorInput != 0);
			} //end of password if statement
			else
			{
				cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
				cout << "Wrong password or username!" << endl;
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			}

			break;
		}//end of case 2
		case '3':
		{

			cout << setfill('*') << setw(120) << "*" << endl;
			cout << setfill(' ') << setw(70) << "Student Login Portal" << endl;
			cout << setfill('*') << setw(120) << "*" << endl;

			if (Login() == true)
			{

				system("color 7"); // changes text color to white
			StudentFlag:
				char StudentInput;
				do {
					system("cls");
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << setfill(' ') << setw(70) << "Student Portal" << endl;
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << "1- Update Profile \n2- View Supervisor Profile \n3- Project Status \n4- Tasks With Deadlines \n5- Grades \nb- Back \nPlease make a choice: "; cin >> StudentInput;

					if (StudentInput == '1')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "UPDATE PROFILE" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						string tempEnrollment;
						cout << "Please enter your Enrollment no: "; cin >> tempEnrollment;
						for (int i = 0; i < StudentSize; i++)
						{
							if (tempEnrollment == StudentObject[i].getStudentEID())
							{
								cout << endl << "Record found!" << endl;
								StudentObject[i].ShowProfile();
								StudentObject[i].UpdateProfile(StudentObject);
								cout << endl << "---Updated successfully!---" << endl;
								break;
							}
							else if (tempEnrollment != StudentObject[i].getStudentEID())
							{
								cout << "Record not found!" << endl;
								break;
							}
						}

						system("pause");
						system("cls");
					}
					else if (StudentInput == '2')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "SUPERVISOR PROFILE" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						string tempEID;
						if (ProjectObject[0].getProjectId() == 0
							&& ProjectObject[1].getProjectId() == 0)
						{
							cout << "No supervisors/projects assigned yet!" << endl;

							system("pause");
							goto StudentFlag;
						}

						cout << "Please enter your Enrollment ID: "; cin >> tempEID;
						
						if (tempEID == StudentObject[0].getStudentEID()
							&& ProjectObject[0].getProjectId() != 0
							&& ProjectObject[1].getProjectId() != 0)
						{
							SupervisorObject[0].ShowProfile();
						}
						else if (tempEID == StudentObject[1].getStudentEID()
							&& ProjectObject[0].getProjectId() != 0
							&& ProjectObject[1].getProjectId() != 0)
						{
							SupervisorObject[1].ShowProfile();
						}


						system("pause");
						system("cls");
					}
					else if (StudentInput == '3')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "PROJECT STATUS" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						cout << "Project Stauts: " << StudentObject->ProStatus(ProjectObject) << endl;

						system("pause");
						system("cls");
					}
					else if (StudentInput == '4')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "TASKS AND DEADLINES" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						if (ProjectObject[0].getProjectId() == 0
							&& ProjectObject[1].getProjectId() == 0)
						{
							cout << "No supervisors/projects assigned yet!" << endl;

							system("pause");
							goto StudentFlag;
						}
						else
						{
							cout << "Task Assigned: " << SupervisorObject->getAssignTask() << endl;
							cout << "Task Deadline: " << SupervisorObject->getAssignedTaskDate() << endl;
						}
						

						system("pause");
						system("cls");
					}
					else if (StudentInput == '5')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "PROJECT GRADES" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						if (ProjectObject[0].getProjectId() == 0
							&& ProjectObject[1].getProjectId() == 0)
						{
							cout << "No students or projects assigned yet!" << endl;

							system("pause");
							goto StudentFlag;
						}
						else
						{
							string tempEID;
							cout << "Please enter your Enrollment Number: "; cin >> tempEID;
							if (tempEID == StudentObject[0].getStudentEID())
							{
								cout << "Grade: " << EvaluatorObject[0].getGrade(&ProjectObject[0]) << endl;
							}
							else if (tempEID == StudentObject[1].getStudentEID())
							{
								cout << "Grade: " << EvaluatorObject[1].getGrade(&ProjectObject[1]) << endl;
							}

						}


						system("pause");
						system("cls");
					}
					else if (StudentInput == 'b')
					{
						system("cls");
						goto MainLoginScreen;
					}
					else
					{
						cout << "Invalid choice!" << endl;
						system("pause");

					}//end of if statement

				} while (StudentInput != 0);
			} //end of password if statement
			else
			{
				cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
				cout << "Wrong password or username!" << endl;
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			}

			break;
		}//end of case 3
		case '4':
		{
			cout << setfill('*') << setw(120) << "*" << endl;
			cout << setfill(' ') << setw(70) << "Evaluator Login Portal" << endl;
			cout << setfill('*') << setw(120) << "*" << endl;

			if (Login() == true)
			{
				system("color 7"); // changes text color to white

			EvaluatorFlag:

				char EvaluatorInput;
				do {
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << setfill(' ') << setw(70) << "Evaluator Portal" << endl;
					cout << setfill('*') << setw(120) << "*" << endl;
					cout << "1- Grade Project \n2- Grade Assigned \nb- Back \nPlease make a choice: "; cin >> EvaluatorInput;
					if (EvaluatorInput == '1')
					{
						
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "GRADE PROJECT" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						for (int i = 0; i < ProjectSize; i++)
						{
							if (ProjectObject[i].getProjectId() == 0 || EvaluatorObject[i].getFName() == "Empty" 
								|| EvaluatorObject[i].getLName() == "Empty")
							{
								cout << "Please projects and add evaluators first!" << endl;
								break;
							}
							else
							{
								cout << "Project ID:" << ProjectObject[i].getProjectId() << endl;
								EvaluatorObject[i].GradeProject(&ProjectObject[i]);
							}
							
						}
						system("pause");
						system("cls");
					}
					else if (EvaluatorInput == '2')
					{
						system("cls");
						cout << setfill('*') << setw(120) << "*" << endl;
						cout << setfill(' ') << setw(70) << "GRADE" << endl;
						cout << setfill('*') << setw(120) << "*" << endl;

						for (int i = 0; i < ProjectSize; i++)
						{
							ofstream writeTo("EvaluatedProject.dat", ios::binary);
							ifstream ReadTo("EvaluatedProject.dat", ios::binary);
							if (!writeTo)
							{
								cout << "Sorry, file could not be created!" << endl;
								exit(1); //safely exits application
							}

							if (ProjectObject[i].getProjectId() == 0 || EvaluatorObject[i].getFName() == "Empty"
								|| EvaluatorObject[i].getLName() == "Empty")
							{
								cout << "Please add projects and evaluators first!" << endl;
								break;
							}
							else
							{
								cout << "Project " << ProjectObject[i].getProjectId() << ":" << endl;
								//writeTo.write(reinterpret_cast<const char*> (&ProjectObject), sizeof(ProjectObject));
								writeTo.open("EvaluatedProjects", ios::app | ios::binary);
								writeTo << "Project " << ProjectObject[i].getProjectId() << ":" << endl;
								cout << "Grade: " << EvaluatorObject[i].getGrade(&ProjectObject[i]) << endl;
								writeTo << "Grade: " << EvaluatorObject[i].getGrade(&ProjectObject[i]) << endl << endl;
							}
							
							//open for append
							//writeTo.open("GROUP.DAT", ios::app | ios::out | ios::in | ios::binary);

							//	//write to file
							//	writeTo.write(reinterpret_cast<char*>(&EvaluatorObject[i]), sizeof(EvaluatorObject));
							//	

							//	ReadTo.seekg(0); //reset to start of file

							//			   //read first person
							//			   //file.read(reinterpret_cast<char*>(&pers), sizeof(pers));
							//while (!ReadTo.eof()) //quit on EOF
							//{
							//	cout << "\nPerson:"; //display person
							//	EvaluatorObject->ShowProfile(); //read another person
							//	ReadTo.read(reinterpret_cast<char*>(&EvaluatorObject[i]), sizeof(EvaluatorObject));
							//}

							cout << endl;

							writeTo.close();

						}
						system("pause");
						system("cls");
					}
					else if (EvaluatorInput == 'b')
					{
						system("cls");
						goto MainLoginScreen;
					}//end of if statement

				} while (EvaluatorInput != '0');
			} //end of password if statement
			else
			{
				cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
				cout << "Wrong password or username!" << endl;
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			}
			break;
		}//end of case 4
		default:
			cout << "wrong input!" << endl;
			break;
		}
	}while (UserChoice != '0');

	return 0; // end of int main
}

