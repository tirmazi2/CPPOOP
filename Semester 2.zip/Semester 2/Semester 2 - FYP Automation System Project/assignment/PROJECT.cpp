#include "PROJECT.h"

//Class Project Related
Project::Project(int e, string a, string b, string c, string d)
{
	P_Title = a;
	P_Detail = b;
	P_S_Date = c;
	P_E_Date = d;
	P_Id = e;
}

Project::~Project()
{
}

void Project::CreatProfile()
{
	cout << "Please enter Project ID: ";
	cin >> P_Id;
	cout << "Please enter Project Title: ";
	cin.ignore(); getline(cin, P_Title);
	cout << "Please enter Project Details: ";
	cin.ignore();
	getline(cin, P_Detail);
	cout << "Please enter Project Start Date (DD/MM/YYYY): ";
	cin >> P_S_Date;
	cout << "Please enter Project End Date (DD/MM/YYYY): ";
	cin >> P_E_Date;

	//For Filing 
	ofstream writeTo;
	writeTo.open("ProjectDeatails.txt", ios::app | ios::binary);
	writeTo << setfill('*') << setw(120) << "*" << endl;
	writeTo << setfill(' ') << setw(70) << "Project Deatails" << endl;
	writeTo << setfill('*') << setw(120) << "*" << endl;

	writeTo << setfill(' ') << setw(45) << "Project ID: \t\t\t\t\t\t" << P_Id << endl;
	writeTo << setfill(' ') << setw(46) << "Project Title:\t\t\t\t\t" << P_Title << endl;
	writeTo << setfill(' ') << setw(48) << "Project Details:\t\t\t\t\t" << P_Detail << endl;
	writeTo << setfill(' ') << setw(51) << "Project Start Date:\t\t\t\t\t" << P_S_Date << endl;
	writeTo << setfill(' ') << setw(49) << "Project End Date:\t\t\t\t\t" << P_E_Date << endl;

	writeTo.close();
}

void Project::ShowProfile()
{
	cout << "Project ID: " << P_Id << endl;
	cout << "Project Title: " << P_Title << endl;
	cout << "Project Details: " << P_Detail << endl;
	cout << "Project Start Date: " << P_S_Date << endl;
	cout << "Project End Date: " << P_E_Date << endl;
	cout << endl;

}
// Searches a record
void Project::ProjectSearch(Project ProjectTemp[], int& ProjectSize)
{
	int temp;
	cout << "Please enter Project ID: "; cin >> temp;
	for (int i = 0; i < ProjectSize; ++i)
	{
		if (temp == ProjectTemp[i].P_Id)
		{
			ProjectTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
}
//Deletes a project record
void Project::ProjectDelete(Project *ProjectTemp, int& ProjectSize)
{
	int Del;
	int count = 0;
	cout << "Please enter id to delete: "; cin >> Del;
	for (int i = 0; i < ProjectSize; ++i)
	{
		//Finds element in the array
		if (Del == ProjectTemp[i].P_Id)
		{
			if (i == ProjectSize - 1)
			{
				ProjectSize--;
			}
			else
			{
				//Lessens loop size from last position and then shifts to the right
				for (int j = i; j < ProjectSize - 1; ++j)
				{
					//Main condition to Swap ("Delete") each location
					ProjectTemp[j] = ProjectTemp[ProjectSize - 1];
					// updates the size for all student for loops
					ProjectSize--;
				}
			}
			//Counter to execute if statement
			++count;
		}//end of if statement (main)
	}//end of for
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] ProjectTemp;
}

int Project::getProjectId()
{
	return P_Id;
}
//Writing to File
void Project::writeToFile(Project *ProjectObject)
{
	/*ofstream WObjectCounter;
	WObjectCounter.open("TempObjectCounter.txt");

	if (!WObjectCounter.is_open())
	{
	cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{

	WObjectCounter.close();

	remove("ObjectCounter.txt");
	rename("TempObjectCounter.txt", "ObjectCounter.txt");
	}*/

	ofstream writeFile;
	writeFile.open("TempSupervisorDetail.txt", ios::out);

	if (!writeFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			writeFile.write((char *)(&ProjectObject[index]), sizeof(ProjectObject[index]));
		}
		writeFile.close();

		remove("SupervisorDetail.txt");
		rename("TempSupervisorDetail.txt", "SupervisorDetail.txt");
	}
}
//Reading
void Project::readFromFile(Project *ProjectObject)
{
	/*ifstream bookCounter;
	bookCounter.open("ObjectCounter.txt");

	if (!bookCounter.is_open())
	{
	cout << "\n\n\t  * ERROR Unable To Open Counter File ..";
	}
	else
	{
	bookCounter.close();
	}*/

	ifstream readFile;
	readFile.open("SupervisorDetail.txt", ios::in);

	if (!readFile.is_open())
	{
		cout << "\n\n\t  * ERROR Unable To Open Book File ..";
	}
	else
	{
		for (int index = 0; index < 2; index++)
		{
			readFile.read((char *)(&ProjectObject[index]), sizeof(ProjectObject[index]));
		}
		readFile.close();
	}
}
//Sequential
void Project::readSequential(Project *ProjectObject)
{
	ifstream readFrom;
	readFrom.open("ProjectDetail.txt");

	cout << endl << endl;
	cout << "Stored and calling as a sequential file" << endl;
	readFrom.open("ProjectDeatails.txt");
	string line;
		while (!readFrom.eof())
		{
			getline(readFrom, line);
			cout << line << endl;
		}
}