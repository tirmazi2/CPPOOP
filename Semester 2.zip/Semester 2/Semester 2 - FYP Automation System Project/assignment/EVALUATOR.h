#pragma once
#include "PROJECT.h"
#include "ADMIN.h"

class Evaluator : public Project, public Admin
{
	int marks;
	char grade;
	string F_Name;
	string L_Name;
	string University;
	string Area_Exp;
	string Department;
	Project *p;
public:
	//Default Parameterized Constructor
	Evaluator(int mar = 0, char gr = '\0', string a = "Empty", string b = "Empty", string c = "Empty", string d = "Empty", string dep = "Empty");
	~Evaluator();
	void CreatProfile(); //Creates New Evaluator Profile
	void ShowProfile(); //Shows Evaluator Profile
	void EvaluatorSearch(Evaluator EvaluatorTemp[], int& EvaluatorSize); //Search
	void EvaluatorDelete(Evaluator *EvaluatorTemp, int& EvaluatorSize); //Delete
	void GradeProject(Project *p);
	string getFName();
	string getLName();
	char getGrade(Project *p); //Gets Marks
	void writeToFile(Evaluator *EvaluatorObject);
	void readFromFile(Evaluator *EvaluatorObject);
};
