#pragma once
#include "ADMIN.h"
#include "PROJECT.h"



class Student : public Admin
{
	int Year;
	string F_Name;
	string L_Name;
	string Enrollment;
	string Semester;
	string Session;
	string ProjectStatus;
	Project *p;

public:
	//Default Parameterized Constructor
	Student(string a = "Empty", string b = "Empty", string c = "Empty", string d = "Empty", string e = "Empty", int f = 2019, string PStatus = "Not Assigned");
	~Student();
	void CreatProfile(); //Creates New Student Profile 
	void ShowProfile(); //Shows Student Profile
	void UpdateProfile(Student *s); //Shows Student Profile
	void StudentSearch(Student Studenttemp[], int& StudentSize); //For searching
	void StudentDelete(Student *Studenttemp, int& StudentSize); //For deleting
	void setStudentSize(int& StudentSize);//sets Size
	string getStudentEID(); //returns Student Enrollment ID
	string ProStatus(Project *p); //returns Project Status
	void writeToFile(Student *StudentObject); //writes to a file
	void readFromFile(Student *StudentObject); //reads from a file
};