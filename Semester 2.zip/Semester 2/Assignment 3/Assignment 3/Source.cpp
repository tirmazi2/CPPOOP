#include <iostream>
#include <string>
using namespace std;

class User {
protected:
	string name;
	int password;
	string role;
public:
	virtual void Login() = 0;
	virtual void showProfile() = 0;
};
class Student :public User {

	string firstName;

	string lastName;

	string enrollment;

	int semester;

	string session;

	int year;

public:
	void Login()
	{
		cout << "enter the name:";
		cin >> name;
		cout << "enter the password:";
		cin >> password;
		cout << "enter the role:";
		cin >> role;
	}

	Student(string f = "xyz", string l = "xyz", string e = "01-235191-006", int s = 2, string se = "spring", int y = 2019)

	{

		firstName = f;

		lastName = l;

		enrollment = e;

		semester = s;

		session = se;

		year = y;

	}


	Student(string name, int id)

	{

		firstName = name;

		enrollment = id;

	}
	void createProfile() {

		cout << endl << "please enter the first name:";

		cin >> firstName;

		cout << endl << "please enter the last name:";

		cin >> lastName;

		cout << endl << "please enter the enrollment:";

		cin >> enrollment;

		cout << endl << "please enter the semester:";

		cin >> semester;

		cout << endl << "please enter the session:";

		cin >> session;

		cout << endl << "please enter the year:";

		cin >> year;

	}

	void showProfile() {

		cout << endl << "The first name is:" << firstName;

		cout << endl << "The last name is :" << lastName;

		cout << endl << "The enrollment is:" << enrollment;

		cout << endl << "The semester is:" << semester;

		cout << endl << "The session is:" << session;

		cout << endl << "The year is:" << year;


	}

	bool operator==(Student s) {

		if (firstName == s.firstName&& enrollment == s.enrollment) {

			return true;

		}

		else {

			return false;

		}

	}

};
class Project {

	string title;

	string detail;

	string startDate;

	string endDate;

	string id;

	Student*s1;

	Student* s2;

public:

	Project(string t = "xyz", string dT = "xyz", string sD = "21-March-2018", string eD = "22-June-2018", string i = "12bd")

	{

		title = t;

		detail = dT;

		startDate = sD;

		endDate = eD;

		id = i;

	}

	Project(int p_id, string p_title, string p_details, Student *sA, Student* sB)

	{

		id = p_id;

		title = p_title;

		detail = p_details;

		s1 = sA;

		s2 = sB;

	}

	void createProfile() {

		cout << endl << "please enter the project tile:";

		cin >> title;

		cout << endl << "please enter the project detail:";

		cin >> detail;

		cout << endl << "please enter the start date:";

		cin >> startDate;

		cout << endl << "please enter the end date:";

		cin >> endDate;

		cout << endl << "please enter the project id:";

		cin >> id;

	}

	void showProfile() {

		cout << endl << "The project title is:" << title;

		cout << endl << "The project detail is :" << detail;

		cout << endl << "The start date is:" << startDate;

		cout << endl << "The end date is:" << endDate;

		cout << endl << "The project id is:" << id;

	}

	bool matchstudent(Student *s) {

		if (s1 == s)

		{

			return true;

		}

		else if (s2 == s) {

			return true;

		}


		else

			return false;

	}

};
class Supervisor : public User {

	string firstName;

	string lastName;

	string department;

	string area_of_expertise;

	Student *s;

	Project *p;

public:
	int pas = 12345;

	void Login()
	{
		cout << "enter the name:";
		cin >> name;
		cout << "enter the password;";
		cin >> password;
		cout << "enter the role";
		cin >> role;

	}
	Supervisor(string fN = "xyz", string lN = "xyz", string dE = "CS", string aE = "oop")

	{

		firstName = fN;

		lastName = lN;

		department = dE;

		area_of_expertise = aE;

	}

	Supervisor(Student *a, Project *r)
	{
		s = a;

		p = r;
	}

	void createProfile() {

		cout << endl << "please enter the first name:";

		cin >> firstName;

		cout << endl << "please enter the last name:";

		cin >> lastName;

		cout << endl << "please enter the department:";

		cin >> department;

		cout << endl << "please enter the area of expertise:";

		cin >> area_of_expertise;

	}

	void showProfile() {

		cout << "student profile:" << endl;
		s->showProfile();

		cout << "project details:" << endl;

		p->showProfile();

		cout << endl;

		cout << endl << "The first name is:" << firstName;

		cout << endl << "The last name is :" << lastName;

		cout << endl << "The department is:" << department;

		cout << endl << "The area of expertise include:" << area_of_expertise;

		cout << endl;


	}

};
class Evaluator {

	string grade;

	string name;

public:

	Evaluator()

	{

		string g;

		string e;

	}

	void createProfile()

	{

		cout << "enter your name:";

		cin >> name;

		cout << "enter the grade you want to give:";

		cin >> grade;

	}

	void showProfile()

	{

		cout << "the name of the evaluator is: " << name << endl;

		cout << "the grade is:" << grade << endl;

	}

};

class Admin : public User {
	Project *proj;
public:
	int p = 12345;
	void Login()
	{
		cout << "enter the name:";
		cin >> name;
		cout << "enter the password:";
		cin >> password;
		cout << "enter the role";
		cin >> role;
	}
	Admin(Project*j)
	{
		proj = j;
	}
	void Assignproject(Project *proj)
	{
		proj->createProfile();
	}
	void showProfile()
	{
		proj->showProfile();
	}

};


int main()
{
	int b = 12345;

	int c;

	Student s;

	Project p;

	Supervisor ss(&s, &p);
	Evaluator e;
	Admin a(&p);
	char ch;

	Student s1("ahmer", 412);

	Student s2("Nawaz", 756);

	Project p1(245, "Robot", "Based on AI", &s1, &s2);


	Student s3("alia", 412);

	Student s4("khan", 756);

	Project p2(211, "Web App", "Php", &s3, &s4);


	Student s5("kashif", 899);


	bool d = p1.matchstudent(&s4);

	cout << "faculty" << endl;

	cout << endl << "enter the password:";

	cin >> c;

	do {

		if (b == c)

		{

			cout << endl;

			cout << "Enter A for student" << endl;

			cout << "Enter B for project" << endl;

			cout << "Enter C for supervisor" << endl;

			cout << "Enter D for Evaluation" << endl;

			cout << "Enter E for Administrator" << endl;

			cout << "enter X to terminate" << endl;

			cout << "Enter your preference in capital letter:";



			cin >> ch;

			switch (ch)

			{

			case 'A':

				cout << "Enter the details of the student:" << endl;

				s.createProfile();

				cout << endl;

				s.showProfile();

				cout << endl;

				break;

			case 'B':

				cout << "The details of the project:" << endl;


				cout << endl;

				p.showProfile();

				cout << endl;


				if (d == true)

					cout << "The Student is already Registred!" << endl;

				else

					cout << "The Student is Not  Registred!" << endl;

				break;

			case 'C':

				cout << "Enter the details of the supervisor:" << endl;
				cout << endl;

				ss.showProfile();

				cout << endl;

				break;
			case 'D':

				cout << "The Evaluation:" << endl;

				e.createProfile();

				cout << endl;

				e.showProfile();

				cout << endl;

				break;

			case 'E':

				cout << "The Administrator:" << endl;

				a.Assignproject(&p);

				cout << endl;



				break;

			}


		}

		else

			cout << "password is incorrect";

		if (ch == 'X')

		{

			break;

		}



	} while (ch != 'X');
}






