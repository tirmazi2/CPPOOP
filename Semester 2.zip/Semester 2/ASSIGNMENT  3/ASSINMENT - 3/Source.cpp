#include <iostream>
#include <string>
#include <Windows.h>
using namespace std;

class USER
{
public:
	USER();
	~USER();

	virtual void Login() = 0;
	virtual void viewProfile() = 0;

protected:
	string username, password, role;
};
class Project;
class supervisor;
class student;
int StudentSize = 2;
int ProjectSize = 2;

Project *ProjectObject = new Project[ProjectSize];
Student *StudentObject_1 = new Student[StudentSize];
Student *StudentObject_2 = new Student[StudentSize];

USER::USER()
{
	username = " ";
	password = " ";
	role = " ";
}

USER::~USER()
{
}

class Student : public USER
{
public:
	Student(int id = 0, string name = "Ali", string e = "01-235182-00", string sess = "Morning", string sem = "3rd", int y = 2019);
	~Student();
	void setStudentValue()
	{
		cout << "Please enter Student ID: "; cin >> S_ID;
		if (S_ID < 0)
		{
			cout << "Invalid ID! setting to 1" << endl;
			S_ID = 1;
		}
		cout << "Please enter Student Name: "; cin.ignore(); getline(cin, S_Name);
		cout << "Please enter enrollment ID: "; cin >> enrol;
		cout << "Please enter session: "; cin >> session;
		cout << "Please enter semester: "; cin >> semester;
		cout << "Please enter enrollment year: "; cin >> year;
	}
	void viewProfile()
	{
		cout << "Student ID: " << S_ID << endl;
		cout << "Student Name: " << S_Name << endl;
	}

	void Login()
	{
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;
		system("cls");
		if (username == "123" && password == "123")
		{
			cout << "==========STUDENT==========" << endl;
			if (StudentObject_2->getStudentID() == 0 && StudentObject_2->getStudentName() == "Ali")
			{
				cout << "No students added yet!" << endl;
			}
			else if (StudentObject_2->getStudentID() != 0 && StudentObject_2->getStudentName() != "Ali")
			{
				for (int i = 0; i < 2; i++)
				{
					cout << "Student 1:" << endl; StudentObject_1[i].viewProfile();
					cout << endl << "Student 2:" << endl; StudentObject_2[i].viewProfile(); cout << endl;
				}
			}

			system("pause");
			system("cls");
		}
		else
		{
			cout << "Wrong Password" << endl;
		}

	}

	//Getters
	int getStudentID()
	{
		return S_ID;
	}
	string getStudentName()
	{
		return S_Name;
	}

private:
	int S_ID;
	string S_Name;
	string enrol;
	string session;
	string semester;
	string year;
} StudentObject;

Student::Student(int id, string e, string sess, string sem, string name, int y)
{
	S_ID = id;
	S_Name = name;
	enrol = e;
	session = sess;
	semester = sem;
	year = y;
}

Student::~Student()
{
}

class Supervisor;

class Project
{
public:
	Project(Student *s1, Student *s2, Supervisor *sup, string title, string detai, int id);
	Project()
	{
		ProjectID = 0;
		ProjectTitle = "Default: FYP AUTOMATION";
		ProjectDetail = "Default: Final Year Project";
	}
	~Project();
	//Setters
	void setProjectValue()
	{
		cout << "Please enter Project Title: "; cin.ignore(); getline(cin, ProjectTitle);
		cout << "Please enter Project Detail: "; cin.ignore(); getline(cin, ProjectDetail);
	}
	void setProjectID()
	{
		again:
		cout << "Please enter Project ID: "; cin >> ProjectID;
		if (ProjectID < 0)
		{
			cout << "Invalid ID" << endl;
			goto again;
			system("cls");
		}
		
	}
	//Getters
	int getProjectID()
	{
		return ProjectID;
	}
	string getProjectTitle()
	{
		return ProjectTitle;
	}
	string getProjectDetail()
	{
		return ProjectDetail;
	}

	//Condition to prevent same Project ID allocation
	bool MatchProject(Project *ProjectObject, int ProjectSize)
	{
		for (int i = 0; i < 2; i++)
		{
			if (ProjectObject[i].getProjectID() == ProjectObject[i + 1].getProjectID())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	//Condition to prevent same Project allocation to more than 1 group of students
	bool MatchStudent(Student *StudentObject_1, Student *StudentObject_2, int StudentSize)
	{
		for (int i = 0; i < StudentSize; i++)
		{
			/*for (int j = 0; j < StudentSize; j++)
			{*/
			if (/*StudentObject_1[i].getStudentID() == StudentObject_2[j].getStudentID()*/
				StudentObject_1[0].getStudentID() == StudentObject_2[0].getStudentID()
				|| StudentObject_1[1].getStudentID() == StudentObject_2[1].getStudentID()
				|| StudentObject_1[0].getStudentID() == StudentObject_2[1].getStudentID()
				|| StudentObject_1[1].getStudentID() == StudentObject_2[0].getStudentID())
			{
				return true;
			}
			else
			{
				return false;
			}
			/*}*/
		}
	}

	//Prints data
	void Print()
	{
		system("cls");
		cout << "------------Project Details------------" << endl;
		cout << "Project ID: " << ProjectID << endl;
		cout << "Project Title: " << ProjectTitle << endl;
		cout << "Project Details: " << ProjectDetail << endl;
	}

public:
	int ProjectID;
	string ProjectTitle, ProjectDetail;
	Student *StudentObject_1, *StudentObject_2;
	Supervisor *s;
};

Project::Project(Student *s1, Student *s2, Supervisor *sup, string title, string detail, int id)
{
	if (id < 0)
	{
		exit(1);
	}
	else
	{
		ProjectID = id;
	}
	ProjectTitle = title;
	ProjectDetail = detail;
	StudentObject_1 = s1;
	StudentObject_2 = s2;
	s = sup;
}

Project::~Project()
{
}


class Supervisor : public USER
{
public:
	Supervisor();
	~Supervisor();
	void createProfile()
	{
		cout << "Please enter Name: "; cin >> name;
		cout << "Please enter your Field: "; cin >> field;
		cout << "Please enter Field Experience: "; cin >> Exp;
	}
	void viewProfile()
	{
		cout << "Name: " << name << endl;
		cout << "Field: " << field << endl;
		cout << "Field Experience: " << Exp << endl;
	}
	void Login()
	{
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;
		system("cls");
		if (username == "123" && password == "123")
		{
			cout << "==========SUPERVISOR==========" << endl;
			string username;
			cout << "Please enter your username: ";
			cin >> username;
			if (ProjectObject->getProjectID() == 0)
			{
				cout << "Please add Projects first!" << endl;
			}
			else
			{
				for (int i = 0; i < 2; i++)
				{
					if (username == "sup1")
					{
							cout << "Supervisor 1:" << endl;
							s[0].viewProfile();
							cout << "Project Details" << endl;
							ProjectObject[ProjectSize - 1].Print();
							cout << "Assigned Students" << endl;
							for (int j = 0; j < StudentSize; j++)
							StudentObject_1[j].viewProfile();
							system("pause");

					}
					else if (username == "sup2")
					{
						cout << "Supervisor 2:" << endl;
						s[1].viewProfile();
						for (int j = 0; j < 2; j++)
						StudentObject_2[j].viewProfile();
					}

				}
			}
			system("pause");
			system("cls");
		}
		else
		{
			cout << "Wrong Password" << endl;
		}
	}

private:
	string name, field, Exp;
	
} s[2];

Supervisor::Supervisor()
{
	name = "Ali"; field = "Bahria"; Exp = "3 years";
}

Supervisor::~Supervisor()
{
}

class Evaluator : USER
{
public:
	Evaluator();
	~Evaluator();
	void createProfile()
	{
		cout << "Please enter Name: "; cin.ignore(); getline(cin, name);
		cout << "Please enter Name of University: "; cin.ignore(); getline(cin, university);
		cout << "Please enter Field Experience: "; cin.ignore(); getline(cin, Exp);
	}
	void setMarks()
	{
		cout << "Please enter marks: " << endl;
		cin >> mark;
	}
	char Evaluator::getGrade(Project *p)
	{
		if (Evaluator::mark == 0)
		{
			cout << "No projects assigned yet!" << endl;
		}
		else
		{
			if (Evaluator::mark >= 50 && mark <= 59)
			{
				return 'D';
			}
			else if (Evaluator::mark >= 60 && mark <= 69)
			{
				return 'C';
			}
			else if (Evaluator::mark >= 70 && mark < 79)
			{
				return 'B';
			}
			else if (Evaluator::mark >= 80 && mark <= 100)
			{
				return 'A';
			}
			else if (Evaluator::mark >= 1 && mark <= 49)
			{
				return 'F';
			}
			else
			{
				return '\0';
			}
		}
	}

	void viewProfile()
	{
		cout << "==========EVALUATOR==========" << endl;
		cout << "Name: " << name << endl;
		cout << "University: " << university << endl;
		cout << "Field Experience: " << Exp << endl;

	}

	void Login()
	{
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;

		cout << "Connecting";
		for (int i = 0; i < 2; i++)
		{
			cout << ".";
			for (int j = 0; j < 1; j++)
			{
				cout << ".";
				Sleep(500);
				for (int k = 0; k < 1; k++)
				{
					cout << ".";
					Sleep(500);
				}
			}
			Sleep(500);
		}
		cout << endl;

		system("cls");
		if (username == "123" && password == "123")
		{
			e.viewProfile();
			for (int i = 0; i < 2; i++)
			{
				cout << "Project Evaluation" << endl;
				cout << "Project ID: " << ProjectObject->ProjectID << endl;
				e.setMarks();
				e.getGrade(ProjectObject);
			}
			system("pause");
			system("cls");
		}
		else
		{
			cout << "Wrong Password" << endl;
		}
	}
private:
	string name, university, Exp;
	int mark = 0;
} e;

Evaluator::Evaluator()
{
	name = "Saad"; university = "Bahria"; Exp = "5 years";
}

Evaluator::~Evaluator()
{
}

class ADMIN : public USER
{
public:
	ADMIN();
	~ADMIN();
	void Login();
	void viewProfile();
	void AssignProject(Project *proj)
	{
		char condition;
		

		do
		{
		MainScreen: // Jump statement

			system("cls");
			cout << "1- Project Allocation\n2- Add Evaluator \n3- Add Supervisor \n4- Add Student \nb- Exit \nPlease make a choice: "; cin >> condition;
			if (condition == '1')
			{
			//	cout << "How many Projects do you want to add?: "; cin >> ProjectSize;
				//Dynamically sets array size
				/*if (ProjectSize <= 0 || ProjectSize > 2)
				{
					system("cls");
					cout << "Can't add 0 or more than 2 students at once!" << endl;
					break;
				}
				cout << "How many Students do you want to add in this project?: "; cin >> StudentSize;
				if (StudentSize <= 0 || StudentSize > 2)
				{
					system("cls");
					cout << "Can't add 0 or more than 2 students at once!" << endl;
					system("pause");
					system("cls");
					break;
				}*/
				system("cls");

				//Dynamic Arrays
				/*ProjectObject = new Project[ProjectSize];
				StudentObject_1 = new Student[StudentSize];
				StudentObject_2 = new Student[StudentSize];*/

				if (condition == '1')
				{
					system("cls");

					//Project Allocation starts here
					for (int i = 0; i < ProjectSize; i++)
					{

						cout << "==================================" << endl;
						cout << "\t    Project " << i + 1 << endl;
						cout << "==================================" << endl;
						ProjectObject[i].setProjectID();
						ProjectObject[i].setProjectValue();


						if (i == 0)
						{
							for (int j = 0; j < StudentSize; ++j)
							{
								cout << "-----------Student " << j + 1 << "-----------" << endl;
								StudentObject_1[j].setStudentValue();

							}

							//Prevents from allocating same Student ID to different students
							if (StudentObject_1[0].getStudentID() == StudentObject_1[1].getStudentID())
							{
								system("cls");
								cout << "ID MATCH ERROR:- Student ID " << StudentObject_1[0].getStudentID()
									<< " already exists, please correct then try again!" << endl;
								system("pause");
								break;
							}

							cout << "-----------Supervisor-----------" << endl;
							s[0].createProfile();
						}
						else if (i == 1)
						{
							for (int j = 0; j < StudentSize; ++j)
							{
								cout << "-----------Student " << j + 1 << "-----------" << endl;
								StudentObject_2[j].setStudentValue();

								//Prevents from allocating same Student ID to different students
								if (StudentObject_2[0].getStudentID() == StudentObject_2[1].getStudentID())
								{
									system("cls");
									cout << "ID MATCH ERROR:- Student ID " << StudentObject_1[0].getStudentID()
										<< " already exists, please correct then try again!" << endl;
									system("pause");
									break;
								}
								cout << "-----------Supervisor-----------" << endl;
								s[1].createProfile();
								//Prevents from Assigning same student ID										
								if (ProjectObject->MatchStudent(StudentObject_1, StudentObject_2, StudentSize))
								{
									system("cls");
									cout << "Student ID: " << StudentObject_2[j].getStudentID()
										<< " already assigned to another project, please correct then try 			again!" << endl;
									system("pause");
									system("cls");
									break;
								}
							}
						}
						//Prevents from Assigning same Project ID
						ProjectObject->MatchProject(ProjectObject, ProjectSize);
						if (ProjectObject->MatchProject(ProjectObject, ProjectSize) == true)
						{
							system("cls");
							cout << "Prject ID already assigned and can't be reassigned!" << endl;
							system("pause");
							system("cls");

							//delete[] ProjectObject;
							//delete[] StudentObject_1;
							//delete[] StudentObject_2;
							break;
						}
						else
						{
							continue;
						}

					}//end of Project for loop
				}//end of 1
			}
			else if (condition == '2')
			{
				e.createProfile();
			}
			else if(condition == '3')
			{
				for(int i = 0; i < 2; i++)
				s[i].createProfile();
			}
			else if (condition == '4')
			{
				int temp;
				cout << "How many groups do you want to add?: ";
				cin >> temp;
				for (int i = 0; i < temp; i++)
				{
					if (temp <= 0 || temp > 2)
					{
						cout << "Can't add 0 or more than 2 groups at the same time!" << endl;
						break;
					}
					else if(temp == 1)
					{
							cout << "How many students do you want to add?: ";
							cin >> temp;
							if (temp <= 0 || temp > 2)
							{
								cout << "Can't add 0 or more than 2 students at the same time!" << endl;
							}
							else
							{
								for (int i = 0; i < temp; i++)
								{
									cout << endl << "Student " << i + 1 << ": " << endl;
									StudentObject_1[i].setStudentValue();
								}
							}
					}
					else if (temp == 2)
					{
						cout << endl << endl;
						StudentObject_1[i].setStudentValue();
						cout << endl << endl;
						StudentObject_2[i].setStudentValue();
					}
				}
				
			}
			else if (condition == 'b')
			{
			End:
				system("cls");
				condition = 0;
			}
		} while (condition != 0);

	}

private:
	string designation;
	Project *p;
};

ADMIN::ADMIN()
{
	designation = "Admin";
}

ADMIN::~ADMIN()
{
}

void ADMIN::Login()
{
	cout << "Username: "; cin >> username;
	cout << "Password: "; cin >> password;
	if (username == "123" && password == "123")
	{
		AssignProject(ProjectObject);
	}
	else
	{
		cout << "Wrong password" << endl;
	}
}

void ADMIN::viewProfile()
{
	cout << "Designation" << designation << endl;
}

int main()
{
	char choice;
	ADMIN a;

	do
	{
		cout << "1- Admin \n2- Supervisor\n3- Evaluator \n4- Student \n0- Exit \nPlease enter a choice: "; cin >> choice;
		system("cls");
		if (choice == '1')
		{
			cout << "==========ADMIN==========" << endl;
			a.Login();
		}
		else if (choice == '2')
		{
			cout << "==========SUPERVISOR==========" << endl;
			s->Login();
		}
		else if (choice == '3')
		{
			cout << "==========EVALUATOR==========" << endl;
			e.Login();
		}
		else if (choice == '4')
		{
			cout << "==========STUDENT==========" << endl;
			StudentObject.Login();
		}
		else
		{
			cout << "Exiting";
			for (int i = 0; i < 3; i++)
			{
				cout << ".";
				Sleep(500);
			}
			cout << endl;
		}

	} while (choice != '0');

	return 0;
}