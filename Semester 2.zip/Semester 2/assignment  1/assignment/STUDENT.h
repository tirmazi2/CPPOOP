#include <iostream> //Standard Library
#include <string> //String Library
#include <fstream> //For file handling Library
using namespace std;


class Student
{
	string F_Name;
	string L_Name;
	string Enrollment;
	string Semester;
	string Session;
	int Year;
	string ProjectStatus;
	int GroupId;
	

public:
	//Default Parameterized Constructor
	Student(string a = "John", string b = "Smith", string c = "01-234567-89", string d = "2nd", string e = "Morning", int f = 2019, string PStatus = "Not Assigned"/*, SupRecord *SupervisorObject*/);
	~Student();
	void CreatProfile(); //Creates New Student Profile 
	void ShowProfile(); //Shows Student Profile
	void UpdateProfile(); //Shows Student Profile
	string ProStatus(); //returns Project Status
	void StudentSearch(Student Studenttemp[], int& StudentSize); //For searching
	void StudentDelete(Student *Studenttemp, int& StudentSize); //For deleting
	void setStudentSize(int& StudentSize);//sets Size
	int getStudentGroupID();
	friend class SupRecord;
	friend class Evaluator;
};