#include "SUPERVISOR.h"
#include <fstream>

ofstream SupervisorFile; //Object for filing

//Class Supervisor Record Related
SupRecord::SupRecord(string a, string b, string c, string d, string FT, string ST, int g1id, int g2id, string task)
{
	F_Name = a;
	L_Name = b;
	Department = c;
	Area_Exp = d;
	FirstTopic = FT;
	SecondTopic = ST;
	GroupIDAssign_1 = g1id;
	GroupIDAssign_2 = g2id;
	Task = task;
}

SupRecord::~SupRecord()
{
}
void SupRecord::ProposedTopic(SupRecord *SupervisorObject)
{
	SupervisorFile.open("SupervisorTopics.txt");
	
		cout << "Please enter topics you want to propose" << endl;
		SupervisorFile << "Please enter topics you want to propose" << endl;
		cout << "First Topic: ";
		cin.ignore(); //Prevent getline from skipping input
		getline(cin, SupervisorObject->FirstTopic);
		SupervisorFile << "First Topic: " << SupervisorObject->FirstTopic << endl;
		cout << "Second Topic: ";
		cin.ignore(); //Prevent getline from skipping input
		getline(cin, SupervisorObject->SecondTopic);
		SupervisorFile << "Second Topic: " << SupervisorObject->SecondTopic << endl;

	SupervisorFile.close();
}

void SupRecord::CreatProfile()
{
	char temp;
	
	SupervisorFile.open("Supervisors.txt");

	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	SupervisorFile << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	SupervisorFile << "Department: " << Department << endl;
	cout << "Please enter your Area of Expertise: ";
	cin >> Area_Exp;
	SupervisorFile << "Area of Expertise: " << Area_Exp << endl;
	cout << endl << "How many groups do you want to assign? : "; cin >> temp;
	SupervisorFile << endl << "How many groups do you want to assign? : " << temp << endl;
	cout << "Please enter Student Group ID to assign: ";
	if (temp == '1')
	{
		 cin >> GroupIDAssign_1;
		 SupervisorFile << "Group ID to assigned: " << GroupIDAssign_1 << endl;
	}
	else if(temp == '2')
	{
		SupervisorFile << "Please enter Student Group ID to assign: " << endl;
		cout << "First Group ID: ";	cin >> GroupIDAssign_1;
		SupervisorFile << "First Group ID: " << GroupIDAssign_1 << endl;
		cout << "Second Group ID: "; cin >> GroupIDAssign_2;
		SupervisorFile << "Second Group ID: " << GroupIDAssign_2 <<endl;
	}
	else
	{
		cout << "You Can't assign '0' or more than 2 students!" << endl;
	}

	SupervisorFile.close();
}

void SupRecord::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
	cout << "Proposed Topics" << endl;
	cout << "1- " << FirstTopic << endl;
	cout << "2- " << SecondTopic << endl;
	cout << "-----Groups Assigned-----" << endl;
	cout << "First Group: " << GroupIDAssign_1 << endl;
	cout << "Second Group: " << GroupIDAssign_2 << endl << endl;
}
void SupRecord::SupervisorSearch(SupRecord SupervisorTemp[], int& SupervisorSize)
{
	string TempFirstName, TempLastName;
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;
	for (int i = 0; i < SupervisorSize; ++i)
	{
		if (TempFirstName == SupervisorTemp[i].F_Name && TempLastName == SupervisorTemp[i].L_Name)
		{
			SupervisorTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
}

//Deletes a project record
void SupRecord::SupervisorDelete(SupRecord *SupervisorTemp, int& SupervisorSize)
{
	int count = 0;
	string TempFirstName, TempLastName;
	
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;
	
	for (int i = 0; i < SupervisorSize; ++i)
	{
		//Finds element in the array
		if (TempFirstName == SupervisorTemp[i].F_Name && TempLastName == SupervisorTemp[i].L_Name)
		{
	
			if (i == SupervisorSize - 1)
			{
				SupervisorSize--;
			}
			else
			{
				//Lessens loop size from last position and then shifts to the right
				for (int j = i; j < SupervisorSize - 1; ++j)
				{
					//Forgot why did i added that statement :)
					if (SupervisorSize == SupervisorSize - 1)
					{
						break;
					}
					//Main condition to Swap ("Delete") each location
					SupervisorTemp[j] = SupervisorTemp[SupervisorSize - 1];

					// updates the size for all student for loops
					SupervisorSize--;
				}
			}
			//Counter to execute if statement
			++count;
		}
	}
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] SupervisorTemp;
}

void SupRecord::AssignTask()
{
	cout << "Group ID: here" << endl;
	cout << "Please enter a Task to assign with date: "; cin.ignore(); getline(cin, Task);
}

string SupRecord::getAssignTask()
{
	return Task;
}

int SupRecord::getGroupID_1()
{
	return GroupIDAssign_1;
}