#include <iostream> //Standard Library
#include <string> //String Library
using namespace std;


class Project
{
	int P_Id;
	string P_Title;
	string P_Detail;
	string P_S_Date;
	string P_E_Date;

public:
	//Default Parameterized Constructor
	Project(int e = 0, string a = "Automated FYP System", string b = "Details will go here", string c = "20/01/2019", string d = "20/10/2019");
	~Project();
	void CreatProfile(); //Creates New Project
	void ShowProfile(); //Shows Project
	void ProjectSearch(Project ProjectTemp[], int& ProjectSize); //Searches a record
	void ProjectDelete(Project *ProjectTemp, int& ProjectSize);
};
