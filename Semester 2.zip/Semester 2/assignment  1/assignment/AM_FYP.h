#include <iostream> //Standard Library
#include <string> //String Library
#include <fstream> //For file handling Library
#include <windows.h> //provides system functions like sleep function etc
using namespace std;

/*Classes Declared
1- Student
2- SupRecord
3- Admin
4- Project
5- Evaluator*/

class Student
{
	string F_Name;
	string L_Name;
	string Enrollment;
	string Semester;
	string Session;
	int Year;
	string ProjectStatus;
	//SupRecord *SupervisorObject;

public:
	//Default Parameterized Constructor
	Student(string a = "John", string b = "Smith", string c = "01-234567-89", string d = "2nd", string e = "Morning", int f = 2019, string PStatus = "Assigned"/*, SupRecord *SupervisorObject*/);
	~Student();
	void CreatProfile(); //Creates New Student Profile 
	void ShowProfile(); //Shows Student Profile
	void UpdateProfile(); //Shows Student Profile
	string ProStatus(); //returns Project Status
};

class Project
{
	int P_Id;
	string P_Title;
	string P_Detail;
	string P_S_Date;
	string P_E_Date;

public:
	//Default Parameterized Constructor
	Project(int e = 0, string a = "Automated FYP System", string b = "Details will go here", string c = "20/01/2019", string d = "20/10/2019");
	~Project();
	void CreatProfile(); //Creates New Project
	void ShowProfile(); //Shows Project

};

class SupRecord
{
	string F_Name;
	string L_Name;
	string Department;
	string Area_Exp;
	string FirstTopic;
	string SecondTopic;
	//Student *StudentObject;
	
public:
	//Default Parameterized Constructor
	SupRecord(string a = "Ayesha", string b = "Ehsan", string c = "IT", string d = "System Administrator", string FT = "OOP Game", string ST = "AI"/*, Student *StudentObject*/);
	~SupRecord();
	void CreatProfile(); //Creates New Supervisor Profile
	void ShowProfile(); //Shows Supervisor Profile
	void ProposedTopic(); // Shows Proposed topics by a perticular supervisor

};
class Admin
{
public:
	//Default Parameterized Constructor
	Admin(string n = "Some Admin", int exp = 5);
	~Admin();

private:
	string name;
	int FieldExp;
};

class Evaluator
{
public:
	//Default Parameterized Constructor
	Evaluator(int mar = 0, char gr = ' ', string a = "Ahsen", string b = "Elahi", string c = "MIT", string d = "Cybersecurity", string dep = "CS");
	~Evaluator();
	void CreateProfile(); //Creates New Evaluator Profile
	void ShowProfile(); //Shows Evaluator Profile
	void setMark(); //Sets Marks
	char getGrade(); //Gets Marks

private:
	int marks;
	char grade;
	string F_Name;
	string L_Name;
	string University;
	string Area_Exp;
	string Department;
};
