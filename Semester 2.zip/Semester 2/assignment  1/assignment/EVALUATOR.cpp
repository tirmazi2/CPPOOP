#include "EVALUATOR.h"
#include "STUDENT.h"

//Class Evaluator Related
char Evaluator::getGrade()
{
	if (Evaluator::marks >= 50 && marks <= 59)
	{
		return 'D';
	}
	else if (Evaluator::marks >= 60 && marks <= 69)
	{
		return 'C';
	}
	else if (Evaluator::marks >= 70 && marks < 79)
	{
		return 'B';
	}
	else if (Evaluator::marks >= 80 && marks <= 100)
	{
		return 'A';
	}
	else
	{
		return 'F';
	}
}
//void Evaluator::setMark(Student *StudentObject)
//{
//	int TempID;
//	cout << "Please enter Group Number: "; cin >> TempID;
//	if (TempID == StudentObject->GroupId)
//	{
//		StudentObject->ShowProfile();
//
//		cout << endl << "Please enter Marks: "; cin >> marks;
//	}
//	else
//	{
//		cout << "No such record found!" << endl;
//	}
//}
void Evaluator::CreateProfile()
{
	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	cout << "Please enter your Are of Expertise: ";
	cin >> Area_Exp;
	cout << "Please enter your University Name: ";
	cin >> University;
}
void Evaluator::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "University: " << University << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
	cout << endl;
}

Evaluator::Evaluator(int mar, char gr, string a, string b, string c, string d, string dep)
{
	marks = mar;
	grade = gr;
	F_Name = a;
	L_Name = b;
	University = c;
	Area_Exp = d;
	Department = dep;
}

Evaluator::~Evaluator()
{
}
//Searches Evaluator
void Evaluator::EvaluatorSearch(Evaluator EvaluatorTemp[], int& EvaluatorSize)
{
	string TempFirstName, TempLastName;
	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;

	for (int i = 0; i < EvaluatorSize; ++i)
	{
		if (TempFirstName == EvaluatorTemp[i].F_Name && TempLastName == EvaluatorTemp[i].L_Name)
		{
			EvaluatorTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
	system("pause");
}
//Deletes a project record
void Evaluator::EvaluatorDelete(Evaluator *EvaluatorTemp, int& EvaluatorSize)
{
	int count = 0;
	string TempFirstName, TempLastName;

	cout << "Please enter Supervisor First Name: "; cin >> TempFirstName;
	cout << "Please enter Supervisor Last Name: "; cin >> TempLastName;

	for (int i = 0; i < EvaluatorSize; ++i)
	{
		//Finds element in the array
		if (TempFirstName == EvaluatorTemp[i].F_Name && TempLastName == EvaluatorTemp[i].L_Name)
		{
				if (i == EvaluatorSize - 1)
				{
					EvaluatorSize--;
				}
				else
				{
					//Lessens loop size from last position and then shifts to the right
					for (int j = i; j < EvaluatorSize - 1; ++j)
					{
						//Main condition to Swap ("Delete") each location
						EvaluatorTemp[j] = EvaluatorTemp[EvaluatorSize - 1];

						// updates the size for all student for loops
						EvaluatorSize--;
					}
				}
				//Counter to execute if statement
				++count;
			}
	}
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] EvaluatorTemp;
}