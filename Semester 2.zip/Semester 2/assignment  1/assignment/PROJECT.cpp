#include "PROJECT.h"



//Class Project Related
Project::Project(int e, string a, string b, string c, string d)
{
	P_Title = a;
	P_Detail = b;
	P_S_Date = c;
	P_E_Date = d;
	P_Id = e;
}

Project::~Project()
{
}

void Project::CreatProfile()
{
	cout << "Please enter Project ID: ";
	cin >> P_Id;
	cout << "Please enter Project Title: ";
	cin >> P_Title;
	cout << "Please enter Project Detail: ";
	cin.ignore();
	getline(cin, P_Detail);
	cout << "Please enter Project Start Date (DD/MM/YYYY): ";
	cin >> P_S_Date;
	cout << "Please enter Project End Date (DD/MM/YYYY): ";
	cin >> P_E_Date;

}
void Project::ShowProfile()
{
	cout << "Project ID: " << P_Id << endl;
	cout << "Project Title: " << P_Title << endl;
	cout << "Project Details: " << P_Detail << endl;
	cout << "Project Start Date: " << P_S_Date << endl;
	cout << "Project End Date: " << P_E_Date << endl;
	cout << endl;

}
// Searches a record
void Project::ProjectSearch(Project ProjectTemp[], int& ProjectSize)
{
	int temp;
	cout << "Please enter Project ID: "; cin >> temp;
	for (int i = 0; i < ProjectSize; ++i)
	{
		if (temp == ProjectTemp[i].P_Id)
		{
			ProjectTemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
}
//Deletes a project record
void Project::ProjectDelete(Project *ProjectTemp, int& ProjectSize)
{
	int Del;
	int count = 0;
	cout << "Please enter id to delete: "; cin >> Del;
	for (int i = 0; i < ProjectSize; ++i)
	{
		//Finds element in the array
		if (Del == ProjectTemp[i].P_Id)
		{
			if (i == ProjectSize - 1)
			{
				ProjectSize--;
			}
			else
			{
				//Lessens loop size from last position and then shifts to the right
				for (int j = i; j < ProjectSize - 1; ++j)
				{
					//Main condition to Swap ("Delete") each location
					ProjectTemp[j] = ProjectTemp[ProjectSize - 1];
					// updates the size for all student for loops
					ProjectSize--;
				}
			}
			//Counter to execute if statement
			++count;
		}//end of if statement (main)
	}//end of for
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}

	//delete[] ProjectTemp;
}