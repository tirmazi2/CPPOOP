#include "ADMIN.h" //Admin class Definition and Declartion
#include "SUPERVISOR.h" //Supervisor class Definition and Declartion
#include "EVALUATOR.h" //Evaluator class Definition and Declartion
#include "STUDENT.h" //Student class Definition and Declartion
#include "PROJECT.h" //Project class Definition and Declartion

	/////////////////////////////////////////////////////////////////////
	//Dynamic Size
	int StudentSize = 2; //static size for testing
	int SupervisorSize = 2;
	int EvaluatorSize = 2;
	int ProjectSize = 2;

	/*1- */Student *StudentObject = new Student[StudentSize];
	/*2- */Admin AdminObject;
	/*3- */SupRecord *SupervisorObject = new SupRecord[SupervisorSize];
	/*4- */Evaluator *EvaluatorObject = new Evaluator[EvaluatorSize];
	/*5- */Project *ProjectObject = new Project[ProjectSize];
	/*test object*/SupRecord supervisorObject;

	//delete statement for all has to be added at the end
	/////////////////////////////////////////////////////////////////////

int main()
{
	/////////////////////////////////////////////////////
					/*Loading Screen*/
	/////////////////////////////////////////////////////
	//cout << "\n\n\n\n\n\n\n\n\t\t\t\t\tLoading:  ";
	//for (int i = 0; i < 20; ++i)
	//{
	//	system("color 4");
	//	cout << "=";
	//	Sleep(150);
	//	//system("color 10");
	//	if (i == 19)
	//	{
	//		cout << ">>>";
	//	}
	//}
	//system("cls");
	//system("color 9");
	/////////////////////////////////////////////////////

MainLoginScreen: //Retrun flag 

	int username, password;
	char UserChoice;
	cout << "1- Admin \n2- Superviosr \n3- Student \n4- Evaluator \n0- Exit \nPlease make a choice: ";
	cin >> UserChoice;
	system("cls");

	switch (UserChoice)
	{
	case '1':
	{
		cout << endl << "\t\t\t\t\t\t\tAdmin Login Portal" << endl;
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;

		/////////////////////////////////////////////////////
		system("color 2"); // changes text color to green
		cout << endl << "Access Granted!" << endl;
		Sleep(300); //delays for 300 ms
		system("cls");
		////////////////////////////////////////////////////

		if (username == 123 && password == 123)
		{
			system("color 7"); // changes text color to white
			char AdminInput;

			AdminMainMenu: //Jumps here
			
			do {
				cout << "1- Update Admin Profile \n2- Project \n3- Superviosr \n4- Evaluator \n5- Student \n0- Exit \nb- Back \nPlease make a choice: ";
				cin >> AdminInput;

					switch (AdminInput)
					{
					case '1':
					{
						system("cls");
						cout << "==========UPDATE ADMIN PROFILE==========" << endl;
						AdminObject.UpdateProfile();

						break;
					} // end of Admin Update
					case '2':
					{
						system("cls");
						cout << "==========PROJECT==========" << endl;
						cout << "1- Add Project \n2- Search Project \n3- Show All Projects \n4- Delete \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << "==========ADD PROJECT==========" << endl;

							for (int i = 0; i < ProjectSize; ++i)
							{
								cout << endl << "Project " << i + 1 << endl;
								ProjectObject[i].CreatProfile();
							}
	
							break;
						}
						case '2':
						{
							system("cls");
							cout << "==========SEARCH PROJECT==========" << endl;
							
							if (ProjectSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								ProjectObject->ProjectSearch(ProjectObject, ProjectSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << "==========SHOW ALL PROJECTS==========" << endl;
							cout << "=====================================" << endl;
							cout << "\t   Project Data" << endl;
							cout << "=====================================" << endl;
							for (int i = 0; i < ProjectSize; ++i)
							{
								ProjectObject[i].ShowProfile();
							}

							break;
						}
						case '4':
						{
							system("cls");
							cout << "==========DELETE A PROJECT==========" << endl;
							ProjectObject->ProjectDelete(ProjectObject, ProjectSize);

							break;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default: cout << "Invalid Choice!" << endl;
							break;
						} // end of Admin (Project)

						break;

					}// end of Project Menu

					case '3':
					{
						system("cls");
						cout << "==========SUPERVISOR==========" << endl;
						cout << "1- Add Supervisor \n2- Search Supervisor \n3- Show All Supervisor \n4- Delete a Supervisor \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << "==========ADD SUPERVISOR==========" << endl;
							for (int i = 0; i < SupervisorSize; ++i)
							{
								cout << endl << "Supervisor " << i + 1 << endl;
								SupervisorObject[i].CreatProfile();
							}

							break;
						}
						case '2':
						{
							system("cls");
							cout << "==========SEARCH SUPERVISOR==========" << endl;

							if (SupervisorSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								SupervisorObject->SupervisorSearch(SupervisorObject, SupervisorSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << "==========SHOW ALL SUPERVISORS==========" << endl;
							cout << "=====================================" << endl;
							cout << "\t Supervisor Data" << endl;
							cout << "=====================================" << endl;

							for (int i = 0; i < SupervisorSize; ++i)
							{
								SupervisorObject[i].ShowProfile();
							}

							break;
						}
						case '4':
						{
							system("cls");
							cout << "==========DELETE A SUPERVISOR==========" << endl;
							SupervisorObject->SupervisorDelete(SupervisorObject, SupervisorSize);

							break;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default:
							break;
						}// end of Admin (Supervisor)

						break;

					} // end of Supervisor Menu
					case '4':
					{
						system("cls");
						cout << "==========EVALUATOR==========" << endl;
						cout << "1- Add Evaluator \n2- Search Evaluator \n3- Show All Evaluators \n4- Delete An Evaluator \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

							switch (AdminInput)
							{
							case '1':
							{
								system("cls");
								cout << "==========ADD EVALUATOR==========" << endl;
								
								for (int i = 0; i < EvaluatorSize; ++i)
								{
									cout << "Evaluator " << i + 1 << endl;
									EvaluatorObject[i].CreateProfile();
								}
								//If user wants to add another
								char AddAgain;
								cout << "Do you want to add something else?: (Y/N): "; cin >> AddAgain;
								if (AddAgain == 'N' || AddAgain == 'n')
								{
									goto MainLoginScreen;
								}
								else
								{
									system("cls");
									goto AdminMainMenu;
								}
								//cout << "Group assigning will go here" << endl;
								break;
							}
							case '2':
							{
								system("cls");
								cout << "==========SEARCH EVALUATOR==========" << endl;
								
								if (EvaluatorSize == 0)
								{
									cout << endl << "List is empty!" << endl;
								}
								else
								{
									EvaluatorObject->EvaluatorSearch(EvaluatorObject, EvaluatorSize);
								}
									
								system("pause");
								system("cls");
								goto AdminMainMenu;
							}
							case '3':
							{
								system("cls");
								cout << "==========SHOW ALL EVALUATORS==========" << endl;
								cout << "=====================================" << endl;
								cout << "\t Evaluators Data" << endl;
								cout << "=====================================" << endl;
								for (int i = 0; i < EvaluatorSize; i++)
								{
									EvaluatorObject[i].ShowProfile();
								}
								
								system("pause");
								system("cls");
								goto AdminMainMenu;
							}
							case '4':
							{
								system("cls");
								cout << "==========DELETE AN EVALUATOR==========" << endl;
								EvaluatorObject->EvaluatorDelete(EvaluatorObject, EvaluatorSize);
	
								system("pause");
								system("cls");
								goto AdminMainMenu;
							}
							case 'b':
							{
								system("cls");
								goto AdminMainMenu;
							}
							default: //Evaluator Default
							{
								cout << "invalid choice!" << endl;
								break;
							}
							break;
							} //end of Switch Evaluator
					}// end of Evaluator Menu
					case '5':
					{
						system("cls");
						cout << "==========STUDENT==========" << endl;
						cout << "1- Add Student \n2- Search Student \n3- Show All Students \n4- Delete Student \nb- Back \nPlease make a choice: ";
						cin >> AdminInput;

						switch (AdminInput)
						{
						case '1':
						{
							system("cls");
							cout << "==========ADD STUDENT==========" << endl;

							//StudentObject->setStudentSize(StudentSize);

							for (int i = 0; i < StudentSize; ++i)
							{
								int count = 0;
								int temp;
								cout << endl << "Student " << i + 1 << endl;
								StudentObject[i].CreatProfile();
								/*temp = StudentObject[i].getStudentGroupID();
								if (temp == StudentObject[i].getStudentGroupID())
								{
									count++;
								}
								if (count > 2)
								{
									cout << "You can't assign same group id to more than 2 students!" << endl;
									system("pause");
									break;
								}*/
							}

							break;
						}
						case '2':
						{
							system("cls");
							cout << "==========SEARCH STUDENT==========" << endl;
							if (StudentSize == 0)
							{
								cout << endl << "List is empty!" << endl;
							}
							else
							{
								StudentObject->StudentSearch(StudentObject, StudentSize);
							}

							break;
						}
						case '3':
						{
							system("cls");
							cout << "==========SHOW ALL STUDENTS==========" << endl;
							cout << "=====================================" << endl;
							cout << "\t   Student Data" << endl;
							cout << "=====================================" << endl;
							for (int i = 0; i < StudentSize; ++i)
							{
								cout << endl << "Student " << i + 1 << endl;
								StudentObject[i].ShowProfile();
							}
							cout << endl;
							system("pause");
							break;
						}
						case '4':
						{
							system("cls");
							cout << "==========DELETE A STUDENT==========" << endl;
							StudentObject->StudentDelete(StudentObject, StudentSize);

							break;
						}
						case 'b':
						{
							system("cls");
							goto AdminMainMenu;
						}
						default:
						{
							cout << "Invalid Choice!" << endl;	
							break;
						}
						
					} //end of switch Student Menu
						break;
					} // end of case 5 "Student"
					case 'b':
					{
						system("cls");
						goto MainLoginScreen;
					}
					default:
					{	//cout << "Invalid Choice" << endl;
					break;
					}

				} //end of Sub Admin (for Admin sub menus)

				system("pause");
				system("cls");
			}while (AdminInput != '0'); //end of do while (Admin)

		} //end of password if statement
		else
		{
			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			cout << "Wrong password or username!" << endl;
			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		}
		break; 

	} //end of case 1 (login)

	case '2':
	{
		cout << endl << "\t\t\t\t\t\t\tSupervisor Login Portal" << endl;
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;

		/////////////////////////////////////////////////////
		system("color 2"); // changes text color to green
		cout << endl << "Access Granted!" << endl;
		Sleep(300); //delays for 300 ms
		system("cls");
		////////////////////////////////////////////////////

		if (username == 123 && password == 123)
		{
		SupervisorFlag: //Jump statement

			system("color 7"); // changes text color to white
			SupRecord SupervisorObject;
			char SupervisorInput;
			do {
				system("cls");
				cout << "1- Propose Topic(s) \n2- ID of Groups Assigned \n3- Assign Tasks with Deadline \n4- View Student Profile\ Project Status\ Task update \n5- Grade of Groups \nb- Back \nPlease make a choice: ";
				cin >> SupervisorInput;

					system("cls");
			
				if (SupervisorInput == '1')
				{
					system("cls");
					cout << "==========PROPOSE TOPIC(S)==========" << endl;
					SupervisorObject.ProposedTopic(&SupervisorObject);
					
				}
				else if (SupervisorInput == '2')
				{
					system("cls");
					cout << "==========ID OF GROUPS ASSINED==========" << endl;
					cout << "Group ID: " << supervisorObject.getGroupID_1() << endl;
					for (int i = 0; i < StudentSize; i++)
					{
						if (supervisorObject.getGroupID_1() == StudentObject[i].getStudentGroupID())
						{
							StudentObject[i].ShowProfile();
						}
					}

					system("pause");
				}
				else if (SupervisorInput == '3')
				{
					system("cls");
					cout << "==========ASSIGN TASK WITH DEADLINE==========" << endl;
					supervisorObject.AssignTask();

					system("pause");
				}
				else if (SupervisorInput == '4')
				{
					system("cls");
					cout << "==========View\ STUDENT PROFILE\ PROJECT STATUS\ TASK UPDATE==========" << endl;
					cout << endl << "1- View Student Profile \n2- View Project Status \n3- Task Update \nPlease make a choice: " ;
					cin >> SupervisorInput;
					if (SupervisorInput == '1')
					{
						cout << "==========VIEW STUDENT PROFILE==========" << endl;

					}
					else if (SupervisorInput == '2')
					{
						cout << "==========PROJECT STATUS==========" << endl;
						cout << "Project Stauts: " << StudentObject->ProStatus() << endl;
					}
					else if (SupervisorInput == '3')
					{
						cout << "==========TASK UPDATE==========" << endl;
						supervisorObject.AssignTask();
					}
					system("pause");
				}
				else if (SupervisorInput == '5')
				{

					cout << "==========GRADES OF GROUPS UNDERSUPERVISION==========" << endl;
					
					system("pause");
				}
				else if (SupervisorInput == 'b')
				{
					system("cls");
					goto MainLoginScreen;
				}
				else
				{
					cout << "Wrong Input, Try again " << endl;

					system("pause");
					system("cls");
				}//end of supervisor if statement
			} while (SupervisorInput != 0);
		} //end of password if statement
		else
		{
			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			cout << "Wrong password or username!" << endl;
			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		}

		break;
	}//end of case 2
	case '3':
	{
		cout << endl << "\t\t\t\t\t\t\tStudent Login Portal" << endl;
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;

		/////////////////////////////////////////////////////
		system("color 2"); // changes text color to green
		cout << endl << "Access Granted!" << endl;
		Sleep(300); //delays for 300 ms
		system("cls");
		////////////////////////////////////////////////////

		if (username == 123 && password == 123)
		{
			system("color 7"); // changes text color to white
		StudentFlag:

			Student StudentObject;
			char StudentInput;
			do {
				system("cls");
				cout << "1- Update Profile \n2- View Supervisor Profile \n3- Project Status \n4- Tasks With Deadlines \n5- Grades \nb- Back \nPlease make a choice: "; cin >> StudentInput;

				if (StudentInput == '1')
				{
					cout << "==========UPDATE PROFILE==========" << endl;
					StudentObject.UpdateProfile();
					cout << endl;
					StudentObject.ShowProfile();

					system("pause");
					system("cls");
				}
				else if (StudentInput == '2')
				{
					SupRecord SupervisorObject;
					cout << "==========SUPERVISOR PROFILE==========" << endl;
					SupervisorObject.ShowProfile();

					system("pause");
					system("cls");
				}
				else if (StudentInput == '3')
				{

					cout << "==========PROJECT STATUS==========" << endl;
					cout << "Project Stauts: " << StudentObject.ProStatus() << endl;

					system("pause");
					system("cls");
				}
				else if (StudentInput == '4')
				{
					cout << "==========TASKS DEADLINES==========" << endl;
					cout << "Task to Assigned: " << supervisorObject.getAssignTask() << endl;

					system("pause");
					system("cls");
				}
				else if (StudentInput == '5')
				{
					Evaluator EvaluatorObject;
					cout << "==========GRADES==========" << endl;
					cout << "Grade: " << EvaluatorObject.getGrade() << endl;

					system("pause");
					system("cls");
				}
				else if (StudentInput == 'b')
				{
					system("cls");
					goto MainLoginScreen;
				}
				else
				{
					cout << "Invalid choice!" << endl;
					system("pause");

				}//end of if statement

			} while (StudentInput != 0);
		} //end of password if statement
		else
		{
			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			cout << "Wrong password or username!" << endl;
			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		}

		break;
	}//end of case 3
	case '4':
	{
		cout << endl << "\t\t\t\t\t\t\tEvaluator Login Portal" << endl;
		cout << "Username: "; cin >> username;
		cout << "Password: "; cin >> password;

		/////////////////////////////////////////////////////
		system("color 2"); // changes text color to green
		cout << endl << "Access Granted!" << endl;
		Sleep(300); //delays for 300 ms
		system("cls");
		////////////////////////////////////////////////////

		if (username == 123 && password == 123)
		{
			system("color 7"); // changes text color to white

		EvaluatorFlag:

			char EvaluatorInput;
			Evaluator EvaluatorObject;

			cout << "=============ASSIGN MARKS=============" << endl;

			//EvaluatorObject.setMark(&StudentObject);
			cout << "Grade: " << EvaluatorObject.getGrade() << endl;

			system("pause");
			system("cls");

		} //end of password if statement
		else
		{
			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
			cout << "Wrong password or username!" << endl;
			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		}
		break;
	}//end of case 4
	default:
		cout << "wrong input!" << endl;
		break;
	}

	return 0; // end of int main
}