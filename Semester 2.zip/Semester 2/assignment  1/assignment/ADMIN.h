#include <iostream> //Standard Library
#include <string> //String Library
#include <fstream> //For file handling Library
#include <windows.h> //provides system functions like sleep function etc
using namespace std;


class Admin
{
public:
	//Default Parameterized Constructor
	Admin(string n = "Some Admin", int exp = 5);
	~Admin();
	void UpdateProfile();


private:
	string name;
	int FieldExp;
};