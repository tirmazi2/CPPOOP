#include <iostream> //Standard Library
#include <string> //String Library

using namespace std;


class SupRecord
{
	string F_Name;
	string L_Name;
	string Department;
	string Area_Exp;
	string FirstTopic;
	string SecondTopic;
	string Task;

	

public:
	//Default Parameterized Constructor
	SupRecord(string a = "Ayesha", string b = "Ehsan", string c = "IT", string d = "System Administrator", string FT = "OOP Game", string ST = "AI", int g1id = 1, int g2id = 2, string task = "Login Screen\t\t26/12/2019");
	~SupRecord();
	
	void CreatProfile(); //Creates New Supervisor Profile
	void ShowProfile(); //Shows Supervisor Profile
	void ProposedTopic(SupRecord *SupervisorObject); // Shows Proposed topics by a perticular supervisor
	void SupervisorSearch(SupRecord SupervisorTemp[], int& SupervisorSize); //Search
	void SupervisorDelete(SupRecord *SupervisorTemp, int& SupervisorSize); //Delete
	void AssignTask();
	string getAssignTask();
	int getGroupID_1();
	int GroupIDAssign_1, GroupIDAssign_2;
};