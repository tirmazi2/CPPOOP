#include "AM_FYP.h"


//Class Student Related
Student::Student(string a, string b, string c, string d, string e, int f, string PStatus)
{
	F_Name = a;
	L_Name = b;
	Enrollment = c;
	Semester = d;
	Session = e;
	Year = f;
	ProjectStatus = PStatus;
}

Student::~Student()
{
}

void Student::CreatProfile()
{
	//storing info to  Admin.txt
	//ofstream AdminStream; // Declaring the object
	//AdminStream.open("Admin.txt", ios::binary); //Creating file

	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	//AdminStream << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Please enter your Enrollment Number: ";
	cin >> Enrollment;
	//AdminStream << "Enrollment Number: " << Enrollment << endl;
	cout << "Please enter your Semester: ";
	cin >> Semester;
	//AdminStream << "Semester: " << Semester << endl;
	cout << "Please enter your Session: ";
	cin >> Session;
	//AdminStream << "Session: " << Session << endl;
	cout << "Please enter Enrollment Year: ";
	cin >> Year;
	//AdminStream << "Enrollment Year: " << Year << endl;
	cout << "Please enter Project Status: ";
	getline(cin, ProjectStatus);
}

string Student::ProStatus()
{
	return ProjectStatus;
}

void Student::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;	
	cout << "Enrollment Number: " << Enrollment << endl;
	cout << "Semester: " << Semester << endl;
	cout << "Session: " << Session << endl;
	cout << "Enrollment Year: " << Year << endl;
	cout << "Project Status: " << ProjectStatus << endl;
}

void Student::UpdateProfile()
{
	int UpdateInput;
	string temp;
	cout << "Type enrollment number of student: "; cin >> temp;
	
	for (int i = 0; i < 2; i++)
	{
		if (temp == Enrollment)
		{
			ShowProfile();
		}
	}
	cout << "1- Student Name \n2- Student Enrollment \n3- Student Semester \n4- Student Session \n5- Student Enrollment Year \n6- Project Status" << endl;
	cout << "What do you want to update?: "; cin >> UpdateInput;
	if (UpdateInput == 1)
	{
		cout << "Please enter your First Name: ";
		cin >> F_Name;
		cout << "Please enter your Last Name: ";
		cin >> L_Name;
	}
	else if (UpdateInput == 2)
	{
		cout << "Please enter your Enrollment Number: ";
		cin >> Enrollment;
	}
	else if (UpdateInput == 3)
	{
		cout << "Please enter your Semester: ";
		cin >> Semester;
	}
	else if (UpdateInput == 4)
	{
		cout << "Please enter your Session: ";
		cin >> Session;
	}
	else if (UpdateInput == 5)
	{
		cout << "Please enter Enrollment Year: ";
		cin >> Year;
	}
	else if (UpdateInput == 6)
	{
		cout << "Please enter your Project Status: ";
		cin >> ProjectStatus;
	}
	else
	{
		cout << "No such information available!" << endl;
	}
	
}

//Class Project Related
Project::Project(int e, string a, string b, string c, string d)
{
	P_Title = a;
	P_Detail = b;
	P_S_Date = c;
	P_E_Date = d;
	P_Id = e;
}

Project::~Project()
{
}

void Project::CreatProfile()
{
	cout << "Please enter Project ID: ";
	cin >> P_Id;
	cout << "Please enter Project Title: ";
	cin >> P_Title;
	cout << "Please enter Project Detail: ";
	getline(cin, P_Detail);
	cout << "Please enter Project Start Date (DD/MM/YYYY): ";
	cin >> P_S_Date;
	cout << "Please enter Project End Date (DD/MM/YYYY): ";
	cin >> P_E_Date;

}
void Project::ShowProfile()
{
	cout << "Project ID: " << P_Id << endl;
	cout << "Project Title: " << P_Title << endl;
	cout << "Project Details: " << P_Detail << endl;
	cout << "Project Start Date: " << P_S_Date << endl;
	cout << "Project End Date: " << P_E_Date << endl;

}

//Class Supervisor Record Related
SupRecord::SupRecord(string a, string b, string c, string d, string FT, string ST)
{
	F_Name = a;
	L_Name = b;
	Department = c;
	Area_Exp = d;
	FirstTopic = FT;
	SecondTopic = ST;
}

SupRecord::~SupRecord()
{
}
void SupRecord::ProposedTopic()
{
	cout << "Please enter topics you want to propose" << endl;
	cout << "First Topic: ";
	cin.ignore(); //Prevent getline from skipping input
	getline(cin, FirstTopic);
	cout << "Second Topic: ";
	cin.ignore(); //Prevent getline from skipping input
	cin >> SecondTopic;
	
}

void SupRecord::CreatProfile()
{
	cout << "Please enter your First Name: ";
	cin >> F_Name; 
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	cout << "Please enter your Are of Expertise: ";
	cin >> Area_Exp;
	ProposedTopic();
	
}

void SupRecord::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
	cout << "Proposed Topics" << endl;
	cout << "1- " << FirstTopic << endl;
	cout << "2- " << SecondTopic << endl;
}

//Class Admin Related
Admin::Admin(string n, int exp)
{
	name = n;
	FieldExp = exp;
}

Admin::~Admin()
{
}

//Class Evaluator Related
char Evaluator::getGrade()
{
	if (Evaluator::marks >= 50 && marks <= 59)
	{
		return 'D';
	}
	else if (Evaluator::marks >= 60 && marks <= 69)
	{
		return 'C';
	}
	else if (Evaluator::marks >= 70 && marks < 79)
	{
		return 'B';
	}
	else if (Evaluator::marks >= 80 && marks <= 100)
	{
		return 'A';
	}
	else
	{
		return 'F';
	}
}
void Evaluator::setMark()
{
	cout << "Please enter Marks: "; cin >> marks;
}
void Evaluator::CreateProfile()
{
	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	cout << "Please enter your Department Name: ";
	cin >> Department;
	cout << "Please enter your Are of Expertise: ";
	cin >> Area_Exp;
	cout << "Please enter your University Name: ";
	cin >> University;
}
void Evaluator::ShowProfile()
{
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "University: " << University << endl;
	cout << "Department: " << Department << endl;
	cout << "Area of Expertise: " << Area_Exp << endl;
}

Evaluator::Evaluator(int mar, char gr, string a, string b, string c, string d, string dep)
{
	marks = mar;
	grade = gr;
	F_Name = a;
	L_Name = b;
	University = c;
	Area_Exp = d;
	Department = dep;
}

Evaluator::~Evaluator()
{
}