//
//
//
//void mainfunction()
//{
//	mainloginscreen: //retrun flag 
//
//	int username, password;
//	char userchoice;
//	cout << "1- admin \n2- superviosr \n3- student \n4- evaluator \nplease make a choice: ";
//	cin >> userchoice;
//	system("cls");
//
//	switch (userchoice)
//	{
//	case '1':
//	{
//		cout << endl << "\t\t\t\t\t\t\tadmin login portal" << endl;
//		cout << "username: "; cin >> username;
//		cout << "password: "; cin >> password;
//
//		/////////////////////////////////////////////////////
//		system("color 2"); // changes text color to green
//		cout << endl << "access granted!" << endl;
//		sleep(300); //delays for 300 ms
//		system("cls");
//		////////////////////////////////////////////////////
//
//		if (username == 123 && password == 123)
//		{
//			/*int admininput;
//			cout << "1- add \n2- search \n3- modify \n4- delete \nplease make a choice: ";
//			cin >> admininput;
//
//			if (admininput == 1)
//			{
//
//			}
//			else if (admininput == 2)
//			{
//			int choice;
//			string temp;
//			cout << "1- student \n2- project \n3- superviosr \n4- evaluator \nplease make a choice: ";
//			cin >> choice;
//			if(choice == 1)
//			{
//			cout << "enter student enrollment number: "; cin >>temp;
//			for()
//			}
//			}*/
//
//			system("color 7"); // changes text color to white
//			char input;
//			do {
//				cout << "1- add student \n2- add project \n3- add superviosr \n4- add evaluator \nplease make a choice: ";
//				cin >> input;
//
//				switch (input)
//				{
//				case '1':
//				{
//					int size;
//
//					//check for size
//					cout << "how many students do you want to add? "; cin >> size;
//					if (size > 0 && size <= 2)
//					{
//						size = size;
//					}
//					else
//					{
//						cout << "you can't add '0' or more than '2' students!" << endl;
//						break;
//					}
//
//					//dynamic array declaration
//					student *studentobject = new student[size];
//
//					for (int i = 0; i < size; ++i)
//					{
//						cout << endl << "student " << i + 1 << endl;
//						studentobject[i].creatprofile();
//					}
//
//					cout << "supervisor" << endl;
//					suprecord supervisorobject;
//					supervisorobject.creatprofile();
//
//					cout << "=====================================" << endl;
//					cout << "\t   student data" << endl;
//					cout << "=====================================" << endl;
//					for (int i = 0; i < size; ++i)
//					{
//						cout << endl << "student " << i + 1 << endl;
//						studentobject[i].showprofile();
//					}
//					cout << endl;
//
//					//releasing memory
//					delete[] studentobject;
//					char addagain;
//					cout << "do you want to add something else?: (y/n): "; cin >> addagain;
//					if (addagain == 'y' || addagain == 'y')
//					{
//						break;
//					}
//					else
//					{
//						system("cls");
//						goto mainloginscreen;
//					}
//
//				}
//				case '2':
//				{
//					project projectobject;
//
//					projectobject.creatprofile();
//					cout << "=====================================" << endl;
//					cout << "\t   project data" << endl;
//					cout << "=====================================" << endl;
//					projectobject.showprofile();
//					cout << endl;
//
//					break;
//				}
//				case '3':
//				{
//					suprecord supervisorobject;
//
//					supervisorobject.creatprofile();
//					cout << "=====================================" << endl;
//					cout << "\t supervisor data" << endl;
//					cout << "=====================================" << endl;
//					supervisorobject.showprofile();
//					cout << endl;
//
//					break;
//				}
//				case '4':
//				{
//					evaluator evaluatorobject;
//
//					evaluatorobject.createprofile();
//					cout << "=====================================" << endl;
//					cout << "\t evaluator data" << endl;
//					cout << "=====================================" << endl;
//					evaluatorobject.showprofile();
//					cout << endl;
//					break;
//				}
//				default: cout << "invalid choice" << endl;
//					break;
//				}
//
//				system("pause");
//				system("cls");
//			} while (input != 0);
//		} //end of password if statement
//		else
//		{
//			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//			cout << "wrong password or username!" << endl;
//			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//		}
//		break;
//	} //end of case 1
//	case '2':
//	{
//		cout << endl << "\t\t\t\t\t\t\tsupervisor login portal" << endl;
//		cout << "username: "; cin >> username;
//		cout << "password: "; cin >> password;
//
//		/////////////////////////////////////////////////////
//		system("color 2"); // changes text color to green
//		cout << endl << "access granted!" << endl;
//		sleep(300); //delays for 300 ms
//		system("cls");
//		////////////////////////////////////////////////////
//
//		if (username == 123 && password == 123)
//		{
//		supervisorflag:
//			system("color 7"); // changes text color to white
//			suprecord supervisorobject;
//			char supervisorinput;
//			cout << "1- propose topic(s) \n2- id of groups assigned \n3- assign taks with deadline \n4- view student profile\project status\task update \n5- grade of groups \nplease make a choice: ";
//			cin >> supervisorinput;
//
//			system("cls");
//
//			if (supervisorinput == '1')
//			{
//				cout << "==========propose topic(s)==========" << endl;
//				supervisorobject.proposedtopic();
//			}
//			else if (supervisorinput == '2')
//			{
//				cout << "==========id of groups assined==========" << endl;
//			}
//			else if (supervisorinput == '3')
//			{
//				cout << "==========assign task with deadline==========" << endl;
//			}
//			else if (supervisorinput == '4')
//			{
//				cout << "==========view\student profile\project status\task update==========" << endl;
//			}
//			else if (supervisorinput == '5')
//			{
//				cout << "==========grades of groups undersupervision==========" << endl;
//			}
//			else
//			{
//				cout << "wrong input, try again " << endl;
//
//				system("pause");
//				system("cls");
//
//				goto supervisorflag;
//			}
//
//		} //end of password if statement
//		else
//		{
//			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//			cout << "wrong password or username!" << endl;
//			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//		}
//
//		break;
//	}//end of case 2
//	case '3':
//	{
//		cout << endl << "\t\t\t\t\t\t\tstudent login portal" << endl;
//		cout << "username: "; cin >> username;
//		cout << "password: "; cin >> password;
//
//		/////////////////////////////////////////////////////
//		system("color 2"); // changes text color to green
//		cout << endl << "access granted!" << endl;
//		sleep(300); //delays for 300 ms
//		system("cls");
//		////////////////////////////////////////////////////
//
//		if (username == 123 && password == 123)
//		{
//			system("color 7"); // changes text color to white
//			studentflag:
//
//			student studentobject;
//			char studentinput;
//			cout << "1- update profile \n2- view supervisor profile \n3- project status \n4- tasks with deadlines \n5- grades \nplease make a choice"; cin >> studentinput;
//
//			if (studentinput == '1')
//			{
//				cout << "==========update profile==========" << endl;
//				studentobject.updateprofile();
//				cout << endl;
//				studentobject.showprofile();
//
//				system("pause");
//				system("cls");
//			}
//			else if (studentinput == '2')
//			{
//				suprecord supervisorobject;
//				cout << "==========supervisor profile==========" << endl;
//				supervisorobject.showprofile();
//
//				system("pause");
//				system("cls");
//			}
//			else if (studentinput == '3')
//			{
//
//				cout << "==========project status==========" << endl;
//				cout << "project stauts: " << studentobject.prostatus() << endl;
//
//				system("pause");
//				system("cls");
//			}
//			else if (studentinput == '4')
//			{
//				cout << "==========tasks deadlines==========" << endl;
//				cout << "sample date goes here" << endl;
//
//				system("pause");
//				system("cls");
//			}
//			else if (studentinput == '5')
//			{
//				evaluator evaluatorobject;
//				cout << "==========grades==========" << endl;
//				cout << "grade: " << evaluatorobject.getgrade() << endl;
//
//				system("pause");
//				system("cls");
//			}
//			else
//			{
//				system("cls");
//				cout << "invalid choice!" << endl;
//				system("cls");
//				system("pause");
//				
//				goto studentflag;
//			}
//
//			cout << "do you want to enter again? (y/n): "; cin >> studentinput;
//			if (studentinput == 'y' || studentinput == 'y')
//			{
//				system("cls");
//				goto studentflag;
//			}
//			else
//			{
//				goto mainloginscreen;
//			}
//
//		} //end of password if statement
//		else
//		{
//			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//			cout << "wrong password or username!" << endl;
//			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//		}
//
//		break;
//	}//end of case 3
//	case '4':
//	{
//		cout << endl << "\t\t\t\t\t\t\tevaluator login portal" << endl;
//		cout << "username: "; cin >> username;
//		cout << "password: "; cin >> password;
//
//		/////////////////////////////////////////////////////
//		system("color 2"); // changes text color to green
//		cout << endl << "access granted!" << endl;
//		sleep(300); //delays for 300 ms
//		system("cls");
//		////////////////////////////////////////////////////
//
//		if (username == 123 && password == 123)
//		{
//			system("color 7"); // changes text color to white
//			
//			evaluatorflag:
//			
//			char evaluatorinput;
//			evaluator evaluatorobject;
//
//			evaluatorobject.setmark();
//			cout << "grade: " << evaluatorobject.getgrade() << endl;
//			
//			system("pause");
//			system("cls");
//
//			cout << "do you want to enter again? (y/n): "; cin >> evaluatorinput;
//			system("cls");
//			if (evaluatorinput == 'y' || evaluatorinput == 'y')
//			{
//				goto evaluatorflag;
//			}
//			else
//			{
//				goto mainloginscreen;
//			}
//
//		} //end of password if statement
//		else
//		{
//			cout << endl << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//			cout << "wrong password or username!" << endl;
//			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
//		}
//		break;
//	}//end of case 4
//	default:
//		cout << "wrong input!" << endl;
//		break;
//	}
//}