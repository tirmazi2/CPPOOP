#include "STUDENT.h"


// Class Student Related
Student::Student(string a, string b, string c, string d, string e, int f, string PStatus)
{
	F_Name = a;
	L_Name = b;
	Enrollment = c;
	Semester = d;
	Session = e;
	Year = f;
	ProjectStatus = PStatus;
}

Student::~Student()
{
}

void Student::CreatProfile()
{
	//storing info to  Admin.txt
	//ofstream AdminStream("Admin.txt", ios::app | ios::binary);  // Declaring the object
	//AdminStream.open("Admin.txt"); //opening file to write

	cout << "Please enter Group ID: ";
	cin >> GroupId;
	cout << "Please enter your First Name: ";
	cin >> F_Name;
	cout << "Please enter your Last Name: ";
	cin >> L_Name;
	//AdminStream << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Please enter your Enrollment Number: ";
	cin >> Enrollment;
	//AdminStream << "Enrollment Number: " << Enrollment << endl;
	cout << "Please enter your Semester: ";
	cin >> Semester;
	//AdminStream << "Semester: " << Semester << endl;
	cout << "Please enter your Session: ";
	cin >> Session;
	//AdminStream << "Session: " << Session << endl;
	cout << "Please enter Enrollment Year: ";
	cin >> Year;
	//AdminStream << "Enrollment Year: " << Year << endl;
	cout << "Please enter Project Status: ";
	cin.ignore();
	getline(cin, ProjectStatus);

	//AdminStream.close();
}

string Student::ProStatus()
{
	return ProjectStatus;
}

void Student::ShowProfile()
{
	cout << "Group ID: " << GroupId << endl;
	cout << "Name: " << F_Name << " " << L_Name << endl;
	cout << "Enrollment Number: " << Enrollment << endl;
	cout << "Semester: " << Semester << endl;
	cout << "Session: " << Session << endl;
	cout << "Enrollment Year: " << Year << endl;
	cout << "Project Status: " << ProjectStatus << endl;
}

void Student::UpdateProfile()
{
	int UpdateInput;
	string temp;
	cout << "Type enrollment number of student: "; cin >> temp;

	for (int i = 0; i < 2; i++)
	{
		if (temp == Enrollment)
		{
			cout << endl;
			ShowProfile();
			
		}
		else
		{
			cout << "No record found!" << endl;

			system("pasue");
			break;
		}
	}
	cout << endl << "1- Student Name \n2- Student Enrollment \n3- Student Semester \n4- Student Session \n5- Student Enrollment Year \n6- Project Status" << endl;
	cout << "What do you want to update?: "; cin >> UpdateInput;
	if (UpdateInput == 1)
	{
		cout << "Please enter your First Name: ";
		cin >> F_Name;
		cout << "Please enter your Last Name: ";
		cin >> L_Name;
	}
	else if (UpdateInput == 2)
	{
		cout << "Please enter your Enrollment Number: ";
		cin >> Enrollment;
	}
	else if (UpdateInput == 3)
	{
		cout << "Please enter your Semester: ";
		cin >> Semester;
	}
	else if (UpdateInput == 4)
	{
		cout << "Please enter your Session: ";
		cin >> Session;
	}
	else if (UpdateInput == 5)
	{
		cout << "Please enter Enrollment Year: ";
		cin >> Year;
	}
	else if (UpdateInput == 6)
	{
		cout << "Please enter your Project Status: ";
		cin.ignore();
		getline(cin,ProjectStatus);
	}
	else
	{
		cout << "No such information available!" << endl;
	}

}
void Student::StudentSearch(Student Studenttemp[], int& StudentSize)
{
	string temp;
	cout << "Please enter student enrollment number: "; cin >> temp;
	for (int i = 0; i < StudentSize; ++i)
	{
		if (temp == Studenttemp[i].Enrollment)
		{
			Studenttemp[i].ShowProfile();
		}
		else
		{
			cout << "No such record found!" << endl;
		}
	}
}

//Deletes a student record
void Student::StudentDelete(Student *Studenttemp, int& StudentSize)
{
	string Del;
	int count = 0;
	cout << "Please enter id to delete: "; cin >> Del;
	for (int i = 0; i < StudentSize; ++i)
	{
		//Finds element in the array
		if (Del == Studenttemp[i].Enrollment)
		{	
					//Main condition to Swap ("Delete") each location
					Studenttemp[i] = Studenttemp[StudentSize - 1];
					// updates the size for all student for loops
					StudentSize--;
			//Counter to execute if statement
			++count;
			break;
		}//end of if main
	}//end of for loop
	if (count == 0)
	{
		cout << "Nothing found!" << endl;
	}
	else
	{
		cout << "Found and deleted!" << endl << endl;
	}
	
	//delete[] Studenttemp;
}

void Student::setStudentSize(int& StudentSize)
{
	cout << "How many Students you wanna add?: "; cin >> StudentSize;
}

int Student::getStudentGroupID()
{
	return GroupId;
}

//Topics assigned by the supervisor
//void Student::TopicBySupervisor(/*SupRecord TempObject*/)
//{
	
//}