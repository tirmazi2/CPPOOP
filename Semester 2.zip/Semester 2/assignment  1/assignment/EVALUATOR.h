#include <iostream> //Standard Library
#include <string> //String Library

using namespace std;


class Evaluator
{
public:
	//Default Parameterized Constructor
	Evaluator(int mar = 90, char gr = 'A', string a = "Ahsen", string b = "Elahi", string c = "MIT", string d = "Cybersecurity", string dep = "CS");
	~Evaluator();
	void CreateProfile(); //Creates New Evaluator Profile
	void ShowProfile(); //Shows Evaluator Profile
	//void setMark(Student *StudentObject); //Sets Marks
	char getGrade(); //Gets Marks
	void EvaluatorSearch(Evaluator EvaluatorTemp[], int& EvaluatorSize); //Search
	void EvaluatorDelete(Evaluator *EvaluatorTemp, int& EvaluatorSize); //Delete
	

private:
	int marks;
	char grade;
	string F_Name;
	string L_Name;
	string University;
	string Area_Exp;
	string Department;
	friend class Student;
};
