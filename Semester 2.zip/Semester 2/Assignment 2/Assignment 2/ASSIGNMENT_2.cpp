#include "ASSIGNMENT_2.h"


//Project Related
bool Project::MatchStudent(Student *Student_1, Student *Student_2)
{
		
		if (Student_2->getStudentID() == Student_1->getStudentID()
		&& Student_2->getStudentName() == Student_1->getStudentName())
		{
			return true;
		}
		else
		{
			return false;
		}
}

Project::Project(Student* s3, Student* s4, int p_id, string P_title, string P_detail)
{
	ProjectID = p_id;
	ProjectTitle = P_title;
	ProjectDetails = P_detail;
	s1 = s3;
	s2 = s4;
}

void Project::setProjectValues(Student* StudentObject_1, Student* StudentObject_2)
{
	cout << "===========PROJECT INFORMATION============" << endl;
	cout << "Please enter Project ID: "; cin >> ProjectID;
	cout << "Please enter Project Title: "; cin.ignore(); getline(cin, ProjectTitle);
	cout << "Please enter Project Detail: "; cin.ignore(); getline(cin, ProjectDetails);
	cout << "===========STUDENT INFORMATION============" <<endl;
	cout << "-----------STUDENT 1------------" << endl;
	StudentObject_1->setStudentValue();
	cout << "-----------STUDENT 2------------" << endl;
	StudentObject_2->setStudentValue();
	MatchStudent(StudentObject_1, StudentObject_2);
	if (MatchStudent(StudentObject_1, StudentObject_2) == true)
	{
		cout << "Error, student already exists with same ID!" << endl;
	}
	else
	{
		cout << "Operation was successful!" << endl;
	}
	cout << endl <<"-----------xxxxxxxxxx------------" << endl << endl;
}
void Project::getProjectValues()
{
	cout << "Please enter Project ID: " <<  ProjectID << endl;
	cout << "Please enter Project Title: " << ProjectTitle << endl;
	cout << "Please enter Project Detail: "<<  ProjectDetails << endl;
}

Project::~Project()
{
}

//Student Related
Student::Student(int id, string name)
{
	StudentName = name;
	StudentID = id;
}

void Student::setStudentValue()
{
	cout << "Please enter Student Name: "; cin.ignore(); getline(cin, StudentName);
	cout << "Please enter Student ID: "; cin >> StudentID;
}

void Student::PrintStudentValue() const
{
	cout << "Student Name: " << StudentName << endl;
	cout << "Student ID: " << StudentID << endl;
}

int Student::getStudentID()
{
	return StudentID;
}
string Student::getStudentName()
{
	return StudentName;
}

Student::~Student()
{
}
