#include "ASSIGNMENT_2.h"

int main()
{
	string username, password;

	cout << "Username: "; cin >> username;
	cout << "Password: "; cin >> password;

	if (username == "admin" && password == "admin")
	{
		Student *StudentObject_1, *StudentObject_2;
		Student StudentObject_3, StudentObject_4;

		StudentObject_1 = &StudentObject_3;
		StudentObject_2 = &StudentObject_4;

		do{
			
			system("cls");

			Project ProjectObject_1(StudentObject_1, StudentObject_2);
			Project ProjectObject_2(StudentObject_1, StudentObject_2);
			ProjectObject_1.setProjectValues(StudentObject_1, StudentObject_2);
			for ()
			{

			}
			MatchStudent(StudentObject_1);
			if (MatchStudent(StudentObject_1, StudentObject_2) == true)
			{
				cout << "Error, student already exists with same ID!" << endl;
			}
			else
			{
				cout << "Operation was successful!" << endl;
			}
			cout << endl << "-----------xxxxxxxxxx------------" << endl << endl;

		} while (1);

	}
	else
	{
		cout << "Wrong Password Kiddo! Better luck Next Time" << endl;
	}

	system("pause");
}