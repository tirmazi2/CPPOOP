#include <iostream>
#include <string>
using namespace std;

class Student
{
public:
	Student(int id = 1, string name = "Ali");
	~Student();
	void setStudentValue();
	void PrintStudentValue() const;
	int getStudentID();
	string getStudentName();
private:
	string StudentName;
	int StudentID;
};

class Project
{
public:
	Project(Student* s3, Student* s4, int p_id= 0, string P_title = "Automated-FYP", string P_detail = "Something will go here");
	~Project();
	bool MatchStudent(Student *Student_1, Student *Student_2);
	void setProjectValues(Student* StudentObject_1, Student* StudentObject_2);
	void getProjectValues();
	friend class Student;
private:
	int ProjectID;
	string ProjectTitle, ProjectDetails;
	Student *s1;
	Student *s2;
};
